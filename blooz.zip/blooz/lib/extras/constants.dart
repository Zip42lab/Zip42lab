import 'dart:ui';

/*const primaryColor = Color(0xff2949B6);*/
import 'package:flutter/material.dart';

class Constant {
  static Color blue = Color(0xFF2949B6);
  static Color white = Color(0xfffcfcfd);
  static Color pink = Color(0xffd05757);
  static Color skyblue = Color(0xff2370e7);
  static Color lightBlue = Color(0xFFE5F4FA);
  static Color grey = Color(0xff666768);
  static Color lightGrey = Color(0xffd0cccc);
  static Color black = Color(0xff000000);

  static TextStyle myStyle = const TextStyle(
      fontSize: 17, fontWeight: FontWeight.bold, color: Colors.green);
  static BoxDecoration mydecoration = BoxDecoration(
    border: Border.all(
      color: Color(0xff2b2be8),
      width: 2.0,
    ), //Border.all

    borderRadius: BorderRadius.circular(
      (60),
    ),
  );
  static BoxDecoration myfulldecoration = BoxDecoration(
    color: const Color(0xff2b2be8),
    borderRadius: BorderRadius.circular(60),
  );
  static Icon myIcon = const Icon(
    Icons.arrow_forward_ios_sharp,
    color: Color(0xff2020e8),
  );
  /*static Container mycontainer = Container(
    height: 30,
    width: 30,
    decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color(0xff2b2be8)),
  );*/
  static Card mycard = Card(
    elevation: 10,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(30),
    ),
    child: Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
      ),
    ),
  );
  static Padding mypadding = Padding(
    padding: EdgeInsets.all(35),
    child: Container(
      height: 40,
      width: 180,
    ),
  );
}
