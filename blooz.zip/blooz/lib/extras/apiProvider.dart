// ignore_for_file: file_names, annotate_overrides, overridden_fields, avoid_print

import 'dart:convert';
import 'dart:io';

import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:blooz/pages/home/model/modelMisDistritous.dart';
import 'package:blooz/pages/home/model/modelHistory.dart';
import 'package:blooz/pages/home/model/modelProfile.dart';
import 'package:blooz/pages/home/model/modelTask.dart';
import 'package:blooz/pages/home/view/homeDetails.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:get_storage/get_storage.dart';

class ApiProvider extends GetConnect {
  final baseUrl = 'http://api.blooz.pe/api/';
  final storage = GetStorage();

  // static const String getRouteslistUrl =
  //     BaseUrl + "order/routes-pagination/?page=1&per_page=10";
  // static const String getRouteDetailsUrl = BaseUrl + "order/route/";
  // static const String getDistrictUrl = BaseUrl + "order/city/lima/district";
  // static const String getChangeStatusUrl = BaseUrl + "order/routes/";

  Future<void> login(String email, String password) async {
    Map body = {
      'email': email,
      'password': password,
    };

    var response = await post('auth/request-token', body);

    // var response = await post('auth/request-token', body, headers: {
    //   'Authorization':
    //       'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiY2VlMWNlNDMtNDVkZi00MzJjLWE3Y2ItYzNiNjI3YTZlZjdiIiwidXNlcm5hbWUiOiJ6YXluQGdtYWlsLmNvbSIsImV4cCI6MTY0MjQ0MDQwMSwiZW1haWwiOiJ6YXluQGdtYWlsLmNvbSJ9.MqINrLzAlFrO7A15cVwJfZgQweD0sULKJfqaInd6hvE',
    // });
    print("RES LOGIN: ${response.statusText.toString()}");
    if (response.isOk) {
      print("check");
      print(response.body);
      final data = response.body;
      print(data);
      storage.write("authToken", data['token']);
    } else {
      print("checkerror");
      return Future.error(response.statusText.toString());
    }
  }

  /// Get routes list
  Future<ModelTask> getRoutes(String userId) async {
    String token = storage.read("authToken");
    // String token =
    //     "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6ImY2NWRhYzZhLWEyZWItNDE2OC05OTM5LTk1Nzg3MmMxOTI4YiIsInVzZXJuYW1lIjoiYmxvb3plcjRAYmxvb3oucGUiLCJlbWFpbCI6ImJsb296ZXI0QGJsb296LnBlIiwiaXNfc3VwZXJ1c2VyIjpmYWxzZSwiZXhwIjoxNjU0MjYwMjI0LCJ0ZW5hbnQiOiJwdWJsaWMifQ.UtiazTkU7Wcio6tqv89i8J2f0T7Y55TEbjn9JcIqOyQ";
    print("New token : $token");
    var response = await get(
      "order/routes-pagination/$userId?page=1&per_page=50",
      // "order/routes/?page=1&per_page=10&input=",
      headers: {'Authorization': "Token " + token},
    );

    if (response.isOk) {
      var data = response.body;
      print("EEEEE : ${jsonEncode(data)}");
      return modelTaskFromJson(jsonEncode(data));
    } else {
      return Future.error(response.statusText.toString());
    }
  }

  bool checkLogin() {
    if (storage.hasData("authToken")) {
      String token = storage.read('authToken');

      if (token.isNotEmpty) {
        return true;
      }
    }
    return false;
  }

  Future<ModelTaskDetail> getRouteDetail(String code) async {
    String token = storage.read("authToken");
    print('Token : $token');
    var response = await get('order/route/$code/',
        headers: {'Authorization': "Token " + token});
    if (response.isOk) {
      var data = jsonEncode(response.body);
      print(data);
      var model = modelTaskDetailFromJson(data);
      print('convrted');
      return model;
    } else {
      return Future.error(response.statusText.toString());
    }
  }

  /// For History Route
  Future<ModelHistory> getHistoryRouteDetail(String date) async {
    String token = storage.read("authToken");
    print('Token : $token');
    var params = {'date': date, 'input_opt': ""};
    var response = await get(
      'order/routes-pagination/',
      query: params,
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      var data = jsonEncode(response.body);
      print('responsejj : $data');
      return modelHistoryFromJson(data);
      /*var model = modelTaskDetailFromJson(data);
      print('convrted');
      return model;*/
    } else {
      return Future.error(response.statusText.toString());
    }
  }

  /// for misDistritos

  Future<List<ModelDistritos>> getDistricts() async {
    String token = storage.read("authToken");
    var response = await get(
      'order/city/lima/district',
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      var data = response.body;
      print("getprofile : ${jsonEncode(data)}");
      // storage.write("profile", data);
      // return modelProfileFromJson(jsonEncode(data));
      print('checkRes : $data');
      return modelDistritosFromJson(jsonEncode(data));
    } else {
      print('not working');
      return Future.error(response.statusText.toString());
    }
  }

  /// get profile
  Future<ModelProfile> getProfile() async {
    String token = storage.read("authToken");
    print('Tokenpro : $token');
    var response = await get(
      'profile/profile/',
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      var data = response.body;
      print("getprofile : ${jsonEncode(data)}");
      storage.write("profile", data);
      print('checkRes : $data');
      return modelProfileFromJson(jsonEncode(data));
      //return modelProfileFromJson(jsonEncode(data));
      //return modelProfileFromJson(data);
      // print(response.body);
    } else {
      return Future.error(response.statusText.toString());
    }
  }

  /// accept reject
  Future<void> acceptReject(String selection, String code) async {
    String token = storage.read("authToken");
    Map body = {
      'state': selection,
    };
    print('Token : $token');
    print('CODE $code');
    print('SELECTION $selection');
    var response = await put(
      'order/routes/$code/bloozer/init',
      body,
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      var data = jsonEncode(response.body);
      print('response data $data');
      // var model = modelTaskDetailFromJson(data);
      //return model;
    } else {
      print('CCC');
      return Future.error(response.statusText.toString());
    }
  }

  /// action
  Future<void> getAction(
      {required String action,
      required String context,
      required String orderCode,
      required String routeCode,
      required String imageUrl}) async {
    String token = storage.read("authToken");
    print('TokenAction : $token');
    Map body = {
      'action': action,
      'context': context,
      'orders': orderCode,
    };

    var deliveryMap = {
      'action': action,
      'context': context,
      'end_photo': imageUrl,
    };

    var response = await put(
      'order/routes/$routeCode/bloozer/action',
      action == "DELIVERED" ? deliveryMap : body,
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      //var data = response.body;
      var data = jsonEncode(response.body);
      print("action api : ${jsonEncode(data)}");
    } else {
      print("Action err : ${response.statusText.toString()}");
      return Future.error(response.statusText.toString());
    }
  }

  Future submitPackages({var data}) async {
    String token = storage.read("authToken");
    var response = await put(
      'order/packages/state',
      data,
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      //var data = response.body;
      var code = jsonEncode(response.body);
      print("package state : ${jsonEncode(code)}");
    } else {
      print("package state err : ${response.statusText.toString()}");
      return Future.error(response.statusText.toString());
    }
  }

  Future<String> uploadImage(File image) async {
    String token = storage.read("authToken");

    final pathForm = FormData({
      'filename': "BLOOZ_${DateTime.now().millisecond}.png",
      'content-type': "image/png"
    });

    var response = await post(
      'profile/upload/pre-signed',
      pathForm,
      headers: {'Authorization': "Token " + token},
    );
    if (response.isOk) {
      //var data = response.body;
      var data = jsonEncode(response.body);
      var path = response.body['url'];
      var name = response.body['fields']['key'];
      print("image : ${path + name}");

      // final form = FormData({
      //   'file': MultipartFile(image, filename: image.path),
      //   'acl': response.body['fields']['acl'],
      //   'Content-Type': response.body['fields']['image/png'],
      //   'AWSAccessKeyId': response.body['fields']['AWSAccessKeyId'],
      //   'policy': response.body['fields']['policy'],
      //   'signature': response.body['fields']['signature'],
      // });

      var request = http.MultipartRequest("POST", Uri.parse(path));
      var multipartFile = await http.MultipartFile.fromPath(
        'file',
        image.path,
      );
      request.files.add(multipartFile);
      request.fields['acl'] = response.body['fields']['acl'];
      request.fields['key'] = response.body['fields']['key'];
      request.fields['Content-Type'] = response.body['fields']['Content-Type'];
      request.fields['AWSAccessKeyId'] =
          response.body['fields']['AWSAccessKeyId'];
      request.fields['policy'] = response.body['fields']['policy'];
      request.fields['signature'] = response.body['fields']['signature'];

      var res = await request.send();

      print("RES : ${res.statusCode}");
      return path + name;
    } else {
      print("image err : ${response.statusText.toString()}");
      return Future.error(response.statusText.toString());
    }
  }
}
