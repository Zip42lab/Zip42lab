// ignore_for_file: file_names

import 'package:blooz/extras/apiProvider.dart';
import 'package:blooz/pages/home/view/homeDetails.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../home/view/HomePage.dart';

class LoginController extends GetxController {
  final _provider = ApiProvider();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  var showLoader = false.obs;

  void loginUser() {
    var email = emailController.text;
    var password = passwordController.text;

    if (email.isEmpty) {
      Get.snackbar("", "Enter email");
      return;
    }

    if (password.isEmpty) {
      Get.snackbar("", "Enter password");
      return;
    }
    showLoader.value = true;
    _provider.login(email, password).then((response) {
      print("response");
      Get.to(HomePage());
      showLoader.value = false;
    }).catchError((error) {
      print("responsejggy");
      Get.snackbar("", "$error");
      showLoader.value = false;
    });
  }
}
