// ignore_for_file: file_names, use_key_in_widget_constructors

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/login/controller/loginController.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';

class LoginPage extends StatelessWidget {
  final _controller = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Container(
            child: ListView(
              children: [
                Container(
                  height: Get.width * 0.72,
                  child: Stack(
                    children: [
                      Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          child: Image.asset(
                            'assets/images/banner.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Image.asset('assets/images/logo_blooz.png')),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          'Ingresa a tu cuenta',
                          style: TextStyle(
                              color: Constant.blue,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(height: 32),
                      Text(
                        'Correo',
                        style: TextStyle(color: Colors.black54, fontSize: 13),
                      ),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _controller.emailController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          hintText: "Correo",
                          hintStyle:
                              TextStyle(color: Colors.black54, fontSize: 13),
                          isDense: true,
                        ),
                        keyboardType: TextInputType.text,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Contrasena',
                        style: TextStyle(color: Colors.black54),
                      ),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _controller.passwordController,
                        obscureText: true,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          hintText: "Contraseña",
                          hintStyle:
                              TextStyle(color: Colors.black54, fontSize: 13),
                          isDense: true,
                        ),
                        keyboardType: TextInputType.text,
                      ),
                      SizedBox(height: Get.height * 0.040),
                      Center(
                        child: Container(
                          height: 40,
                          width: Get.width * 0.50,

                          decoration: Constant.myfulldecoration,
                          //alignment: Alignment.center,
                          // alignment: Alignment.center,
                          child: InkWell(
                            onTap: () {
                              if (_controller.showLoader.value) {
                                return;
                              }
                              _controller.loginUser();
                            },
                            child: Obx(() {
                              return Center(
                                child: _controller.showLoader.value
                                    ? const Padding(
                                        padding: EdgeInsets.all(4.0),
                                        child: SpinKitThreeBounce(
                                          color: Colors.white,
                                          size: 20.0,
                                        ),
                                      )
                                    : const Text(
                                        " Ingresar ",
                                        style: TextStyle(color: Colors.white),
                                      ),
                              );
                            }),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
        ]),
      ),
    );
  }
}
