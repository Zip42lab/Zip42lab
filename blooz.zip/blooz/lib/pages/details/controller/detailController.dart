// ignore_for_file: file_names

import 'package:blooz/extras/apiProvider.dart';
import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DetailController extends GetxController {
  var showLoader = false.obs;
  final _provider = ApiProvider();
  late Rx<dynamic> taskDetail = Rx<dynamic>(0);

  void getRouteDetail(String code) {
    print(' ccc : $code');
    showLoader.value = true;
    _provider.getRouteDetail(code).then((response) {
      taskDetail.value = response;
      taskDetail.refresh();
      showLoader.value = false;
    }).catchError((onError) {
      print("EEE : $onError");
      showLoader.value = false;
    });
  }
}
