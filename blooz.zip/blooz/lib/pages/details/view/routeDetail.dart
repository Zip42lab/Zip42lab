// ignore_for_file: use_key_in_widget_constructors, avoid_print, file_names

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/controller/detailController.dart';
import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:blooz/pages/google_map/view/google_map.dart';
import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../home/controller/homeController.dart';
import '../../home/view/selectionDialog.dart';

class RouteDetail extends StatelessWidget {
  final _controller = Get.put(DetailController());
  final HomeController _c = Get.find();

  final String code;
  final int from;
  final int googleDisable;
  RouteDetail(
      {Key? key,
      required this.code,
      required this.from,
      required this.googleDisable})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    /// get route detail api call
    _controller.getRouteDetail(code);

    /// end

    return Scaffold(
      bottomNavigationBar: from == 0
          ? Obx(
              (() => Visibility(
                    visible: _c.hideAcceptReject.value,
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              // dialogBOxForSelect(context, "REJECTED", code);
                              Get.dialog(SelectionDialog(
                                selection: "REJECTED",
                                code: code,
                              ));
                            },
                            child: Container(
                              height: Get.height * 0.07,
                              color: Constant.pink,
                              child: const Center(
                                child: Text(
                                  'Rechazar ruta',
                                  style: TextStyle(color: Colors.white),
                                  // textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              // dialogBOxForSelect(context, "ACCEPTED", code);
                              Get.dialog(SelectionDialog(
                                selection: "ACCEPTED",
                                code: code,
                              ));
                            },
                            child: Container(
                              height: Get.height * 0.07,
                              color: Constant.skyblue,
                              child: const Center(
                                child: Text(
                                  'Aceptar ruta',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )),
            )
          : null,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: InkWell(
          onTap: () {
            Get.back();
          },
          child: const Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
        title: const Text(
          'Detalle de la Route',
          style: TextStyle(color: Colors.black),
        ),
        // iconTheme: const IconThemeData(color: Colors.blue),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            child: ListView(
              scrollDirection: Axis.vertical,
              children: [
                Card(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: _controller.taskDetail == null
                                  ? const Text('')
                                  : Obx(
                                      () => Text(
                                        'Ruta ${_controller.taskDetail.value.code}',
                                        style: const TextStyle(
                                          color: Colors.blue,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ),
                            ),
                            SizedBox(width: Get.width * 0.45),
                          ],
                        ),
                        const SizedBox(height: 0),
                        Row(
                          children: [
                            Obx(
                              () => Text(
                                _controller.taskDetail.value.created,
                                style: const TextStyle(fontSize: 10),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 0),
                        Container(
                          child: googleDisable == 0
                              ? Row(
                                  children: [
                                    Spacer(),
                                    InkWell(
                                      onTap: () {
                                        if (_controller
                                            .taskDetail.value.canStart) {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => MyGoogle(),
                                            ),
                                          );
                                        } else {
                                          Get.snackbar(
                                            "Alert!",
                                            "You can't start now.",
                                            snackPosition: SnackPosition.BOTTOM,
                                          );
                                        }
                                      },
                                      child: Row(
                                        children: const [
                                          Text(
                                            'Ir al mapa',
                                            style: TextStyle(
                                              color: Colors.blue,
                                              fontSize: 13,
                                            ),
                                          ),
                                          Icon(
                                            Icons.arrow_forward_ios,
                                            color: Colors.blue,
                                            size: 15,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                )
                              : Container(),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 5,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Clientes',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black54,
                                ),
                                //textAlign: TextAlign.end,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Obx(() {
                                List<ModelTaskDetailDestination> destinations =
                                    _controller.taskDetail.value.destinations;

                                var clients = getClientsList(destinations);
                                return ListView.separated(
                                  primary: false,
                                  shrinkWrap: true,
                                  itemCount: clients.length,
                                  separatorBuilder: (context, index) {
                                    return const SizedBox(
                                      height: 8,
                                    );
                                  },
                                  itemBuilder: (context, index) {
                                    var client = clients[index];
                                    return Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 15,
                                          backgroundColor: Constant.pink,
                                          backgroundImage: NetworkImage(
                                            client.profilePhoto,
                                          ),
                                        ),
                                        SizedBox(width: Get.width * 0.03),
                                        Text(
                                          client.commercialName,
                                          style: TextStyle(fontSize: 15),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              }),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'info general',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black54),
                                  //textAlign: TextAlign.end,
                                ),
                                SizedBox(height: Get.height * 0.02),
                                Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 10,
                                      backgroundColor: Constant.white,
                                      child: SvgPicture.asset(
                                        "assets/icons/ic_distance.svg",
                                        semanticsLabel: 'Package',
                                        width: 28,
                                        height: 28,
                                      ),
                                    ),
                                    SizedBox(width: Get.width * 0.02),
                                    _controller.taskDetail == null
                                        ? const Text('')
                                        : Obx(() => Text(
                                              '${_controller.taskDetail.value.totalKms}Km',
                                              style:
                                                  const TextStyle(fontSize: 12),
                                            )),
                                  ],
                                ),
                                SizedBox(height: Get.height * 0.01),
                                Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 10,
                                      backgroundColor: Constant.white,
                                      child: SvgPicture.asset(
                                        "assets/icons/ic_time.svg",
                                        semanticsLabel: 'Package',
                                        width: 28,
                                        height: 28,
                                      ),
                                    ),
                                    SizedBox(width: Get.width * 0.02),
                                    _controller.taskDetail == null
                                        ? const Text('')
                                        : Obx(() => Text(
                                              '${_controller.taskDetail.value.totalTime}min',
                                              style:
                                                  const TextStyle(fontSize: 12),
                                            )),
                                  ],
                                ),
                                SizedBox(height: Get.height * 0.01),
                                Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 10,
                                      backgroundColor: Constant.white,
                                      child: SvgPicture.asset(
                                        "assets/icons/ic_acc.svg",
                                        semanticsLabel: 'Package',
                                        width: 28,
                                        height: 28,
                                      ),
                                    ),
                                    SizedBox(width: Get.width * 0.02),
                                    _controller.taskDetail == null
                                        ? const Text('')
                                        : Obx(() => Text(
                                              'S/ ${_controller.taskDetail.value.totalBloozerRate}',
                                              style:
                                                  const TextStyle(fontSize: 12),
                                            )),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Row(
                          children: const [
                            Text(
                              'Paquetes',
                              style: TextStyle(fontSize: 13),
                            ),
                          ],
                        ),
                        SizedBox(height: Get.height * 0.010),
                        Obx(() {
                          List<ModelTaskDetailDestination> destinations =
                              _controller.taskDetail.value.destinations;
                          return ListView.separated(
                            primary: false,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              var destItem = destinations[index];
                              return Row(children: [
                                const SizedBox(width: 0),
                                Center(
                                  child: SvgPicture.asset(
                                    "assets/icons/ic_package.svg",
                                    semanticsLabel: 'Package',
                                    width: 24,
                                    height: 24,
                                  ),
                                ),
                                SizedBox(width: Get.width * 0.02),
                                Text(
                                  '${destItem.deliveryName} : ${destItem.order.length}',
                                  style: const TextStyle(fontSize: 13),
                                ),
                              ]);
                            },
                            separatorBuilder: (context, index) {
                              return const SizedBox(height: 8);
                            },
                            itemCount: destinations.length,
                          );
                        }),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 8,
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: const Text(
                            "Resumen del recorrido",
                            style: TextStyle(color: Colors.black, fontSize: 15),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(bottom: 20),
                          child: Obx(() {
                            List<ModelTaskDetailDestination> destinations =
                                _controller.taskDetail.value.destinations;

                            return ListView.builder(
                                primary: false,
                                shrinkWrap: true,
                                itemCount: destinations.length,
                                itemBuilder: (BuildContext context, int index) {
                                  var destItem = destinations[index];
                                  return Container(
                                    padding: const EdgeInsets.all(3),
                                    child: Row(
                                      children: [
                                        Column(
                                          //crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            SvgPicture.asset(
                                              "assets/icons/ic_pin.svg",
                                              semanticsLabel: 'Package',
                                              width: 28,
                                              height: 28,
                                            ),
                                            DottedLine(
                                              direction: Axis.vertical,
                                              lineLength: Get.height * 0.12,
                                              lineThickness: 1.0,
                                              dashLength: 4.0,
                                              dashColor: Colors.black,
                                              dashRadius: 0.0,
                                              dashGapLength: 4.0,
                                              dashGapColor: Colors.transparent,
                                              dashGapRadius: 0.0,
                                            )
                                          ],
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        // width: Get.width * 0.9,
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                destItem
                                                    .deliveryAddress.address,
                                                style: const TextStyle(
                                                    fontSize: 14),
                                              ),
                                              SizedBox(
                                                  height: Get.height * 0.02),
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.person,
                                                    size: 20,
                                                    color: Constant.grey,
                                                  ),
                                                  SizedBox(
                                                      width: Get.width * 0.02),
                                                  Text(
                                                    destItem.deliveryName,
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        color: Constant.grey),
                                                  )
                                                ],
                                              ),
                                              const SizedBox(height: 8),
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.phone,
                                                    size: 20,
                                                    color: Constant.grey,
                                                  ),
                                                  SizedBox(
                                                      width: Get.width * 0.02),
                                                  Text(
                                                    destItem
                                                        .deliveryPhoneNumber,
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        color: Constant.grey),
                                                  )
                                                ],
                                              ),
                                              const SizedBox(height: 8),
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.crop_square_outlined,
                                                    size: 20,
                                                    color: Constant.grey,
                                                  ),
                                                  SizedBox(
                                                      width: Get.width * 0.02),
                                                  Text(
                                                    destItem.deliveryExtraInfo,
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        color: Constant.grey),
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                });
                          }),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            child: Obx(() => _controller.showLoader.value
                ? Container(
                    color: Colors.white,
                    child: const Center(
                      child: SpinKitThreeBounce(
                        color: Colors.blue,
                        size: 40.0,
                      ),
                    ),
                  )
                : Container()),
          ),
        ],
      ),
    );
  }

  void dialogBOxForSelect(BuildContext context, String selection, String code) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  const Text('Seguro que desea rechazar \n esta ruta?',
                      style: TextStyle(color: Colors.blue, fontSize: 12),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  const Text(
                    'Esta accion no se puede deshacer',
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    children: [
                      const SizedBox(width: 20),
                      InkWell(
                        onTap: () {
                          //Get.to(dialogBOxForConferm(context));

                          dialogBOxForConferm(context);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 20),
                          decoration: Constant.myfulldecoration,
                          child: Text(
                            "Aceptar",
                            style: TextStyle(
                              color: Constant.white,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                      Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 20),
                        decoration: Constant.myfulldecoration,
                        child: Text(
                          "Cancellar",
                          style: TextStyle(
                            color: Constant.white,
                            fontSize: 12,
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  void dialogBOxForConferm(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  Container(
                    child: CircleAvatar(
                      radius: 18,
                      backgroundColor: Constant.blue,
                      child: const Icon(
                        Icons.check,
                        size: 25,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.040),
                  const Text('Se ha elimindo la ruta',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  // const SizedBox(height: 30),
                  const SizedBox(width: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 20),
                    decoration: Constant.myfulldecoration,
                    child: Text(
                      "Aceptar",
                      style: TextStyle(
                        color: Constant.white,
                        fontSize: 12,
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }

  List<Client> getClientsList(List<ModelTaskDetailDestination> destinations) {
    var list = <Client>[];
    for (var item in destinations) {
      for (var order in item.order) {
        // if (!list.contains(order.client)) {
        var available = list.any(
            (element) => element.commercialName == order.client.commercialName);
        if (!available) {
          //print("Client : ${order.client.commercialName}");
          list.add(order.client);
        }
      }
    }
    return list;
  }
}
