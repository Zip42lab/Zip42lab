// To parse this JSON data, do
// ignore_for_file: file_names, prefer_if_null_operators

import 'dart:convert';

ModelTaskDetail modelTaskDetailFromJson(String str) =>
    ModelTaskDetail.fromJson(json.decode(str));

String modelTaskDetailToJson(ModelTaskDetail data) =>
    json.encode(data.toJson());

class ModelTaskDetail {
  ModelTaskDetail({
    required this.code,
    required this.created,
    required this.state,
    required this.humanizeState,
    required this.bloozer,
    required this.deliveryPickupAddress,
    required this.deliveryDate,
    required this.deliverySchedule,
    required this.tracking,
    required this.lastTracking,
    required this.destinations,
    required this.totalKms,
    required this.totalTime,
    required this.totalOrdersWallet,
    required this.totalBloozerRate,
    required this.totalPercentGain,
    required this.totalNumericGain,
    required this.canStart,
    required this.quotation,
  });

  String code;
  String created;
  String state;
  String humanizeState;
  Bloozer bloozer;
  DeliveryAddress deliveryPickupAddress;
  String deliveryDate;
  String deliverySchedule;
  List<Tracking> tracking;
  Tracking lastTracking;
  List<ModelTaskDetailDestination> destinations;
  String totalKms;
  String totalTime;
  String totalOrdersWallet;
  String totalBloozerRate;
  String totalPercentGain;
  String totalNumericGain;
  bool canStart;
  Quotation quotation;

  factory ModelTaskDetail.fromJson(Map<String, dynamic> json) =>
      ModelTaskDetail(
        code: json["code"] == null ? '' : json["code"],
        created: json["created"] == null ? '' : json["created"],
        state: json["state"] == null ? '' : json["state"],
        humanizeState:
            json["humanize_state"] == null ? '' : json["humanize_state"],
        bloozer: Bloozer.fromJson(json["bloozer"]),
        deliveryPickupAddress:
            DeliveryAddress.fromJson(json["delivery_pickup_address"]),
        deliveryDate:
            json["delivery_date"] == null ? '' : json["delivery_date"],
        deliverySchedule:
            json["delivery_schedule"] == null ? '' : json["delivery_schedule"],
        tracking: List<Tracking>.from(
            json["tracking"].map((x) => Tracking.fromJson(x))),
        lastTracking: Tracking.fromJson(json["last_tracking"]),
        destinations: List<ModelTaskDetailDestination>.from(json["destinations"]
            .map((x) => ModelTaskDetailDestination.fromJson(x))),
        totalKms: json["total_kms"] == null ? '' : json["total_kms"],
        totalTime: json["total_time"] == null ? '' : json["total_time"],
        totalOrdersWallet: json["total_orders_wallet"] == null
            ? ''
            : json["total_orders_wallet"],
        totalBloozerRate: json["total_bloozer_rate"] == null
            ? ''
            : json["total_bloozer_rate"],
        totalPercentGain: json["total_percent_gain"] == null
            ? ''
            : json["total_percent_gain"],
        totalNumericGain: json["total_numeric_gain"] == null
            ? ''
            : json["total_numeric_gain"],
        canStart: json["can_start"] == null ? false : json["can_start"],
        quotation: Quotation.fromJson(json["quotation"]),
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "created": created,
        "state": state,
        "humanize_state": humanizeState,
        "bloozer": bloozer.toJson(),
        "delivery_pickup_address": deliveryPickupAddress.toJson(),
        "delivery_date": deliveryDate,
        "delivery_schedule": deliverySchedule,
        "tracking": List<dynamic>.from(tracking.map((x) => x.toJson())),
        "last_tracking": lastTracking.toJson(),
        "destinations": List<dynamic>.from(destinations.map((x) => x.toJson())),
        "total_kms": totalKms,
        "total_time": totalTime,
        "total_orders_wallet": totalOrdersWallet,
        "total_bloozer_rate": totalBloozerRate,
        "total_percent_gain": totalPercentGain,
        "total_numeric_gain": totalNumericGain,
        "can_start": canStart,
        "quotation": quotation.toJson(),
      };
}

class Bloozer {
  Bloozer({
    required this.user,
    required this.profileType,
    required this.city,
    required this.address,
    required this.phoneNumber,
    required this.profilePhoto,
    required this.documentCode,
    required this.available,
    required this.accountBank,
    required this.accountNumber,
    required this.accountCci,
  });

  User user;
  String profileType;
  String city;
  String address;
  String phoneNumber;
  String profilePhoto;
  String documentCode;
  bool available;
  String accountBank;
  String accountNumber;
  String accountCci;

  factory Bloozer.fromJson(Map<String, dynamic> json) => Bloozer(
        user: User.fromJson(json["user"]),
        profileType: json["profile_type"] == null ? '' : json["profile_type"],
        city: json["city"] == null ? '' : json["city"],
        address: json["address"] == null ? '' : json["address"],
        phoneNumber: json["phone_number"] == null ? '' : json["phone_number"],
        profilePhoto:
            json["profile_photo"] == null ? '' : json["profile_photo"],
        documentCode:
            json["document_code"] == null ? '' : json["document_code"],
        available: json["available"] == null ? false : json["available"],
        accountBank: json["account_bank"] == null ? '' : json["account_bank"],
        accountNumber:
            json["account_number"] == null ? '' : json["account_number"],
        accountCci: json["account_cci"] == null ? '' : json["account_cci"],
      );

  Map<String, dynamic> toJson() => {
        "user": user.toJson(),
        "profile_type": profileType,
        "city": city,
        "address": address,
        "phone_number": phoneNumber,
        "profile_photo": profilePhoto,
        "document_code": documentCode,
        "available": available,
        "account_bank": accountBank,
        "account_number": accountNumber,
        "account_cci": accountCci,
      };
}

class User {
  User({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.isStaff,
  });

  String id;
  String firstName;
  String lastName;
  String email;
  bool isStaff;

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"] == null ? '' : json["id"],
        firstName: json["first_name"] == null ? '' : json["first_name"],
        lastName: json["last_name"] == null ? "" : json["last_name"],
        email: json["email"] == null ? '' : json["email"],
        isStaff: json["is_staff"] == null ? false : json["is_staff"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "is_staff": isStaff,
      };
}

class DeliveryAddress {
  DeliveryAddress({
    required this.address,
    required this.district,
    required this.notes,
  });

  String address;
  String district;
  String notes;

  factory DeliveryAddress.fromJson(Map<String, dynamic> json) =>
      DeliveryAddress(
        address: json["address"] == null ? '' : json["address"],
        district: json["district"] == null ? '' : json["district"],
        notes: json["notes"] == null ? '' : json["notes"],
      );

  Map<String, dynamic> toJson() => {
        "address": address,
        "district": district,
        "notes": notes,
      };
}

class ModelTaskDetailDestination {
  ModelTaskDetailDestination(
      {required this.order,
      required this.deliveryName,
      required this.deliveryPhoneNumber,
      required this.deliveryAddress,
      required this.endPhoto,
      required this.deliveryExtraInfo,
      required this.state,
      required this.map,
      required this.id,
      required this.activeStep,
      required this.isPickup,
      required this.kms,
      required this.time,
      y});

  List<Order> order;
  String deliveryName;
  String deliveryPhoneNumber;
  DeliveryAddress deliveryAddress;
  String endPhoto;
  String deliveryExtraInfo;
  String state;
  String map;
  String id;
  int activeStep;
  bool isPickup;
  double kms;
  double time;

  factory ModelTaskDetailDestination.fromJson(Map<String, dynamic> json) =>
      ModelTaskDetailDestination(
        order: List<Order>.from(json["order"].map((x) => Order.fromJson(x))),
        deliveryName:
            json["delivery_name"] == null ? '' : json["delivery_name"],
        deliveryPhoneNumber: json["delivery_phone_number"] == null
            ? ''
            : json["delivery_phone_number"],
        deliveryAddress: DeliveryAddress.fromJson(json["delivery_address"]),
        endPhoto: json["end_photo"] == null ? '' : json["end_photo"],
        deliveryExtraInfo: json["delivery_extra_info"] == null
            ? ''
            : json["delivery_extra_info"],
        state: json["state"] == null ? '' : json["state"],
        map: json["map"] == null ? '' : json["map"],
        id: json["id"] == null ? 0 : json["id"],
        activeStep: json["active_step"] == null ? 0 : json["active_step"],
        isPickup: json["is_pickup"] == null ? false : json["is_pickup"],
        kms: json["kms"] == null ? 0.0 : json["kms"].toDouble(),
        time: json["time"] == null ? 0.0 : json["time"].toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "order": List<dynamic>.from(order.map((x) => x.toJson())),
        "delivery_name": deliveryName,
        "delivery_phone_number": deliveryPhoneNumber,
        "delivery_address": deliveryAddress.toJson(),
        "end_photo": endPhoto,
        "delivery_extra_info": deliveryExtraInfo,
        "state": state,
        "map": map,
        "id": id,
        "active_step": activeStep,
        "is_pickup": isPickup,
        "kms": kms,
        "time": time,
      };
}

class Order {
  Order({
    required this.id,
    required this.code,
    required this.client,
    required this.deliveryPickupAddress,
    required this.destinations,
  });

  String id;
  String code;
  Client client;
  DeliveryAddress deliveryPickupAddress;
  List<OrderDestination> destinations;

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        id: json["id"] == null ? '' : json["id"],
        code: json["code"] == null ? '' : json["code"],
        client: Client.fromJson(json["client"]),
        deliveryPickupAddress:
            DeliveryAddress.fromJson(json["delivery_pickup_address"]),
        destinations: List<OrderDestination>.from(
            json["destinations"].map((x) => OrderDestination.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "code": code,
        "client": client.toJson(),
        "delivery_pickup_address": deliveryPickupAddress.toJson(),
        "destinations": List<dynamic>.from(destinations.map((x) => x.toJson())),
      };
}

class Client {
  Client({
    required this.user,
    required this.commercialName,
    required this.phoneNumber,
    required this.profilePhoto,
  });

  User user;
  String commercialName;
  String phoneNumber;
  String profilePhoto;

  factory Client.fromJson(Map<String, dynamic> json) => Client(
        user: User.fromJson(json["user"]),
        commercialName:
            json["commercial_name"] == null ? '' : json["commercial_name"],
        phoneNumber: json["phone_number"] == null ? "" : json["phone_number"],
        profilePhoto:
            json["profile_photo"] == null ? "" : json["profile_photo"],
      );

  Map<String, dynamic> toJson() => {
        "user": user.toJson(),
        "commercial_name": commercialName,
        "phone_number": phoneNumber,
        "profile_photo": profilePhoto,
      };
}

class OrderDestination {
  OrderDestination({
    required this.deliveryName,
    required this.deliveryPhoneNumber,
    required this.deliveryAddress,
    required this.endPhoto,
    required this.deliveryExtraInfo,
    required this.state,
    required this.packages,
    required this.id,
    required this.code,
    required this.emailClient,
  });

  String deliveryName;
  String deliveryPhoneNumber;
  DeliveryAddress deliveryAddress;
  String endPhoto;
  String deliveryExtraInfo;
  String state;
  List<Package> packages;
  String id;
  String code;
  String emailClient;

  factory OrderDestination.fromJson(Map<String, dynamic> json) =>
      OrderDestination(
        deliveryName:
            json["delivery_name"] == null ? '' : json["delivery_name"],
        deliveryPhoneNumber: json["delivery_phone_number"] == null
            ? ''
            : json["delivery_phone_number"],
        deliveryAddress: DeliveryAddress.fromJson(json["delivery_address"]),
        endPhoto: json["end_photo"] == null ? '' : json["end_photo"],
        deliveryExtraInfo: json["delivery_extra_info"] == null
            ? ''
            : json["delivery_extra_info"],
        state: json["state"],
        packages: List<Package>.from(
            json["packages"].map((x) => Package.fromJson(x))),
        id: json["id"] == null ? '' : json["id"],
        code: json["code"] == null ? '' : json["code"],
        emailClient: json["email_client"] == null ? '' : json["email_client"],
      );

  Map<String, dynamic> toJson() => {
        "delivery_name": deliveryName,
        "delivery_phone_number": deliveryPhoneNumber,
        "delivery_address": deliveryAddress.toJson(),
        "end_photo": endPhoto,
        "delivery_extra_info": deliveryExtraInfo,
        "state": state,
        "packages": List<dynamic>.from(packages.map((x) => x.toJson())),
        "id": id,
        "code": code,
        "email_client": emailClient,
      };
}

class Package {
  Package({
    required this.packageType,
    required this.packageValue,
    required this.verifiedPackage,
    required this.observationPackage,
    required this.packageCounter,
    required this.orderDestination,
  });

  int packageType;
  String packageValue;
  bool verifiedPackage;
  String observationPackage;
  String packageCounter;
  String orderDestination;

  factory Package.fromJson(Map<String, dynamic> json) => Package(
        packageType: json["package_type"] == null ? '' : json["package_type"],
        packageValue:
            json["package_value"] == null ? '' : json["package_value"],
        verifiedPackage:
            json["verified_package"] == null ? '' : json["verified_package"],
        observationPackage: json["observation_package"] == null
            ? ''
            : json["observation_package"],
        packageCounter:
            json["package_counter"] == null ? '' : json["package_counter"],
        orderDestination:
            json["order_destination"] == null ? '' : json["order_destination"],
      );

  Map<String, dynamic> toJson() => {
        "package_type": packageType,
        "package_value": packageValue,
        "verified_package": verifiedPackage,
        "observation_package": observationPackage,
        "package_counter": packageCounter,
        "order_destination": orderDestination,
      };
}

class Tracking {
  Tracking({
    required this.sender,
    required this.state,
    required this.created,
    required this.humanizeDate,
    required this.context,
  });

  String sender;
  String state;
  String created;
  String humanizeDate;
  String context;

  factory Tracking.fromJson(Map<String, dynamic> json) => Tracking(
        sender: json["sender"] == null ? '' : json["sender"],
        state: json["state"] == null ? '' : json["state"],
        created: json["created"] == null ? '' : json["created"],
        humanizeDate:
            json["humanize_date"] == null ? '' : json["humanize_date"],
        context: json["context"] == null ? '' : json["context"],
      );

  Map<String, dynamic> toJson() => {
        "sender": sender,
        "state": state,
        "created": created,
        "humanize_date": humanizeDate,
        "context": context,
      };
}

class Quotation {
  Quotation({
    required this.route,
    required this.optimizedPrices,
  });

  Route route;
  String optimizedPrices;

  factory Quotation.fromJson(Map<String, dynamic> json) => Quotation(
        route: Route.fromJson(json["route"]),
        optimizedPrices:
            json["optimized_prices"] == null ? '' : json["optimized_prices"],
      );

  Map<String, dynamic> toJson() => {
        "route": route.toJson(),
        "optimized_prices": optimizedPrices,
      };
}

class Route {
  Route({
    required this.status,
    required this.message,
    required this.routeId,
    required this.totalKms,
    required this.totalTime,
    required this.destination,
    required this.pickupOrder,
    required this.pickupAddress,
    required this.selectedRoute,
    required this.pickupDistrict,
    required this.totalBloozerRate,
    required this.totalNumericGain,
    required this.totalPercentGain,
    required this.totalOrdersWallet,
  });

  String status;
  String message;
  int routeId;
  double totalKms;
  double totalTime;
  List<RouteDestination> destination;
  String pickupOrder;
  String pickupAddress;
  bool selectedRoute;
  String pickupDistrict;
  double totalBloozerRate;
  double totalNumericGain;
  double totalPercentGain;
  double totalOrdersWallet;

  factory Route.fromJson(Map<String, dynamic> json) => Route(
        status: json["status"] == null ? '' : json["status"],
        message: json["message"] == null ? '' : json["message"],
        routeId: json["route_id"] == null ? 0 : json["route_id"],
        totalKms:
            json["total_kms"] == null ? 0.0 : json["total_kms"].toDouble(),
        totalTime:
            json["total_time"] == null ? 0.0 : json["total_time"].toDouble(),
        destination: List<RouteDestination>.from(
            json["destination"].map((x) => RouteDestination.fromJson(x))),
        pickupOrder: json["pickup_order"] == null ? '' : json["pickup_order"],
        pickupAddress:
            json["pickup_address"] == null ? '' : json["pickup_address"],
        selectedRoute:
            json["selected_route"] == null ? '' : json["selected_route"],
        pickupDistrict:
            json["pickup_district"] == null ? '' : json["pickup_district"],
        totalBloozerRate: json["total_bloozer_rate"] == null
            ? 0.0
            : json["total_bloozer_rate"].toDouble(),
        totalNumericGain: json["total_numeric_gain"] == null
            ? 0.0
            : json["total_numeric_gain"].toDouble(),
        totalPercentGain: json["total_percent_gain"] == null
            ? 0.0
            : json["total_percent_gain"].toDouble(),
        totalOrdersWallet: json["total_orders_wallet"] == null
            ? 0.0
            : json["total_orders_wallet"].toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "route_id": routeId,
        "total_kms": totalKms,
        "total_time": totalTime,
        "destination": List<dynamic>.from(destination.map((x) => x.toJson())),
        "pickup_order": pickupOrder,
        "pickup_address": pickupAddress,
        "selected_route": selectedRoute,
        "pickup_district": pickupDistrict,
        "total_bloozer_rate": totalBloozerRate,
        "total_numeric_gain": totalNumericGain,
        "total_percent_gain": totalPercentGain,
        "total_orders_wallet": totalOrdersWallet,
      };
}

class RouteDestination {
  RouteDestination({
    required this.kms,
    required this.time,
    required this.type,
    required this.status,
    required this.linkId,
    required this.message,
    required this.customer,
    required this.district,
    required this.destination,
    required this.bloozerRate,
    required this.numericGain,
    required this.percentGain,
    required this.ordersWallet,
    required this.rateTypeApplied,
  });

  double kms;
  double time;
  int type;
  String status;
  String linkId;
  String message;
  String customer;
  String district;
  String destination;
  double bloozerRate;
  double numericGain;
  double percentGain;
  double ordersWallet;
  String rateTypeApplied;

  factory RouteDestination.fromJson(Map<String, dynamic> json) =>
      RouteDestination(
        kms: json["kms"] == null ? 0.0 : json["kms"].toDouble(),
        time: json["time"] == null ? 0.0 : json["time"].toDouble(),
        type: json["type"] == null ? 0 : json["type"],
        status: json["status"] == null ? '' : json["status"],
        linkId: json["link_id"] == null ? "" : json["link_id"],
        message: json["message"] == null ? '' : json["message"],
        customer: json["customer"] == null ? '' : json["customer"],
        district: json["district"] == null ? '' : json["district"],
        destination: json["destination"] == null ? '' : json["destination"],
        bloozerRate: json["bloozer_rate"] == null
            ? 0.0
            : json["bloozer_rate"].toDouble(),
        numericGain: json["numeric_gain"] == null
            ? 0.0
            : json["numeric_gain"].toDouble(),
        percentGain: json["percent_gain"] == null
            ? 0.0
            : json["percent_gain"].toDouble(),
        ordersWallet: json["orders_wallet"] == null
            ? 0.0
            : json["orders_wallet"].toDouble(),
        rateTypeApplied:
            json["rate_type_applied"] == null ? '' : json["rate_type_applied"],
      );

  Map<String, dynamic> toJson() => {
        "kms": kms,
        "time": time,
        "type": type,
        "status": status,
        "link_id": linkId,
        "message": message,
        "customer": customer,
        "district": district,
        "destination": destination,
        "bloozer_rate": bloozerRate,
        "numeric_gain": numericGain,
        "percent_gain": percentGain,
        "orders_wallet": ordersWallet,
        "rate_type_applied": rateTypeApplied,
      };
}
