import 'package:get/get.dart';

class GoogleController extends GetxController {}
