import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:blooz/pages/google_map/model/routePoint.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:location/location.dart' as mapLoc;
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../extras/apiProvider.dart';
import '../model/modelPackageState.dart';

class MapController extends GetxController {
  late mapLoc.LocationData currentLocation;
  var destinationLocation = mapLoc.LocationData;
  late bool _serviceEnabled;
  late mapLoc.PermissionStatus _permissionGranted;
  var reset = true.obs;

  var location = mapLoc.Location();
  final ImagePicker _picker = ImagePicker();
  var image = File("").obs;

  var checksPickup = [].obs;
  var checksDelivery = [].obs;

  var showDeliverSheet = false.obs;
  var switchHasValue = false.obs;
  var panelOpened = false.obs;
  var packageInProgress = "".obs;
  var activeStep = 0.obs;
  var currentDestination = 0.obs;
  var packageStateList = <ModelPackageState>[];
  var imageUrl = "".obs;

  List<RoutePoint> wayPoints = <RoutePoint>[];
  int id = 0;

  //var polylines = {}.obs;
  Completer<GoogleMapController> mapController = Completer();

  Rx<Set<Polyline>> polylines = Rx<Set<Polyline>>({});
  //Set<Polyline> _polylines = {};
  String googleAPIKey = "AIzaSyBWmkpEqqLAeg2uJOlhnNyEqfR9DPW87yg";
  var slideController = PanelController();
  // List<OrderDestination> wayPoints = <OrderDestination>[];

  static double CAMERA_ZOOM = 18;
  static double CAMERA_TILT = 45;
  static double CAMERA_BEARING = 30;

  var pickupLocation = <ModelTaskDetailDestination>[].obs;
  var deliveryLocation = <ModelTaskDetailDestination>[].obs;

  var checks = 0.obs;
  var apiProvider = ApiProvider();
  var showLoader = false.obs;

  var showStart = true.obs;

  void onMapCreated(GoogleMapController c) {
    mapController.complete(c);
    print("checkmap");
    // setMapPins();

    locationSetup();
  }

  setPolylines(RoutePoint point) {
    //polylineCoordinates.clear();
    PolylinePoints polylinePoints = PolylinePoints();
    List<LatLng> polylineCoordinates = [];

    print("polulineone");
    var source = PointLatLng(
      point.source.latitude,
      point.source.longitude,
    );
    print("pointsChecksource: ${point.source.latitude}");

    //var dest = PointLatLng(31.104759, 77.174796);
    var dest = PointLatLng(
      point.destination.latitude,
      point.destination.longitude,
    );
    print("pointsCheckdest: ${point.destination.latitude}");

    polylinePoints
        .getRouteBetweenCoordinates(
      googleAPIKey,
      source,
      dest,
      travelMode: TravelMode.driving,
    )
        .then((PolylineResult result) async {
      print("Set ${result.errorMessage}");

      for (var point in result.points) {
        //  print("pointsChecklength: ${result.points.length}");
        print("Lat: ${point.latitude}, Lng: ${point.longitude}");
        print("poluline4");
        //if (!pointExists(point)) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
        print("poluline4");
        //}
      }

      var lineItem = Polyline(
        polylineId: PolylineId(id.toString()),
        color: Constant.blue,
        jointType: JointType.round,
        width: 6,
        startCap: Cap.roundCap,
        endCap: Cap.buttCap,
        points: polylineCoordinates,
        geodesic: true,
      );
      print("poluline5");
      polylines.value.add(lineItem);
      polylines.refresh();
      // id = id + 1;
      // if (wayPoints.length > id) {
      //   setPolylines(wayPoints[id]);
      // }
    });
    print("poluline6");
  }

  Future<void> _prepareRoutePoints() async {
    wayPoints.clear();
    List<Location> locations = await locationFromAddress(
        pickupLocation[activeStep.value]
            .order[0]
            .destinations[currentDestination.value]
            .deliveryAddress
            .address);

    /*  /// ststic point
    var point = RoutePoint();
    point.source = LatLng(32.110981, 76.278650);
    print("DEST POINT: ${locations[0].latitude} : ${locations[0].longitude}");
    point.destination = LatLng(32.122252, 76.267589);
    wayPoints.add(point);
*/
    ///
    var point = RoutePoint();
    point.source =
        LatLng(currentLocation.latitude!, currentLocation.longitude!);
    print("DEST POINT: ${locations[0].latitude} : ${locations[0].longitude}");
    point.destination = LatLng(locations[0].latitude, locations[0].longitude);
    wayPoints.add(point);

    ///
    // if (wayPoints.length > id) {
    //   setPolylines(wayPoints[id]);
    // }

    setPolylines(point);
  }

  /// for image picker
  Future<void> getImage() async {
    reset.value = false;
    var data = await _picker.pickImage(source: ImageSource.camera);
    image.value = File(data!.path);
    print("FFF ${data.path}");
    reset.value = true;
    apiProvider
        .uploadImage(File(data.path))
        .then((image) => imageUrl.value = image);
  }

//
  void assignChecks(ModelTaskDetail detail) {
    Future.delayed(const Duration(milliseconds: 100), () {
      pickupLocation.clear();
      deliveryLocation.clear();
      for (var model in detail.destinations) {
        //if (model.isPickup) {
        pickupLocation.add(model);
        // } else {
        //   deliveryLocation.add(model);
        // }
      }

      resetProgress();

      // // delivery checks
      // checksDelivery.clear();
      // for (var i in deliveryLocation[0].order) {
      //   checksDelivery.add(false);
      // }
      // checksDelivery.refresh();

      switchHasValue.value = true;
    });
  }

  void resetData() {
    if (reset.value) {
      mapController = Completer();
      Future.delayed(const Duration(milliseconds: 100), () {
        if (wayPoints != null) {
          wayPoints.clear();
        }

        showDeliverSheet.value = false;
        switchHasValue.value = false;
        panelOpened.value = false;
        packageInProgress.value = "";
        activeStep.value = 0;
        currentDestination.value = 0;
      });
    }
  }

  // update variables on progress changed
  Future<void> resetProgress() async {
    checksPickup.clear();
    packageInProgress.value =
        pickupLocation[activeStep.value].order[0].destinations[0].code;
    for (var i in pickupLocation[activeStep.value]
        .order[0]
        .destinations[currentDestination.value]
        .packages) {
      checksPickup.add(false);
    }
    checksPickup.refresh();

    currentLocation = await location.getLocation();
    print("LAT: ${currentLocation.latitude} LNG: ${currentLocation.longitude}");

    animateToCurrentLocation();
    _prepareRoutePoints();

    getSelectedPackages();
  }

  Future<void> locationSetup() async {
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == mapLoc.PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != mapLoc.PermissionStatus.granted) {
        return;
      }
    }

    currentLocation = await location.getLocation();

    print("LAT: ${currentLocation.latitude} LNG: ${currentLocation.longitude}");

    animateToCurrentLocation();
    _prepareRoutePoints();
  }

  Future<void> animateToCurrentLocation() async {
    final c = await mapController.future;
    final p = CameraPosition(
        target: LatLng(currentLocation.latitude!, currentLocation.longitude!),
        zoom: 14.4746);
    c.animateCamera(CameraUpdate.newCameraPosition(p));
  }

  getSelectedPackages() {
    checks.value = 0;
    for (bool item in checksPickup) {
      if (item) {
        checks.value += 1;
      }
    }
  }

  List<Package> getPackages() {
    var packages = pickupLocation[activeStep.value]
        .order[0]
        .destinations[currentDestination.value]
        .packages;
    packageStateList = getPackageSize(packages.length);
    return packages;
  }

  void submitPackages(List<Package> packageList) {
    for (int i = 0; i < packageList.length; i++) {
      var package = packageList[i];
      var check = checksPickup[i];
      packageStateList[i].order_destination = package.orderDestination;
      packageStateList[i].package_counter = package.packageCounter;
      packageStateList[i].verified_package = check;
    }

    var data = jsonEncode(packageStateList);
    print("OBJECT : $data");
    showLoader.value = true;
    apiProvider.submitPackages(data: data).then((response) {
      // Check in the destination index if isPicup then make ShowDeliverySheet false
      showLoader.value = false;
      var step = activeStep.value;
      var activeDestCount = pickupLocation[step].order[0].destinations.length;

      if (currentDestination.value == activeDestCount - 1) {
        if (step == pickupLocation.length - 1) {
          Get.snackbar("Alert!", "Your task finished");
          return;
        }
        currentDestination.value = 0;
        activeStep.value += 1;

        if (pickupLocation[activeStep.value].isPickup) {
          showDeliverSheet.value = false;
        } else {
          showDeliverSheet.value = true;
        }
      } else {
        currentDestination.value += 1;
      }
      resetProgress();
    }).catchError((onError) {
      showLoader.value = false;
    });
  }

  List<ModelPackageState> getPackageSize(int length) {
    var list = <ModelPackageState>[];
    for (int i = 0; i < length; i++) {
      list.add(ModelPackageState());
    }
    return list;
  }

  void callNow(String phone) async {
    var _url = "tel:$phone";
    if (!await launch(_url)) throw 'Could not launch $_url';
  }

  void smsNow(String phone) async {
    var _url = "sms:$phone";
    if (!await launch(_url)) throw 'Could not launch $_url';
  }

  void actionTask(
      {required String action,
      required String context,
      required String orderCode,
      required String routeCode}) {
    apiProvider
        .getAction(
            action: action,
            context: context,
            orderCode: orderCode,
            routeCode: routeCode,
            imageUrl: imageUrl.value)
        .then((value) {});
  }
}
