// ignore_for_file: use_key_in_widget_constructors

import 'dart:io';

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/controller/detailController.dart';
import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:blooz/pages/google_map/controller/mapController.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:im_stepper/stepper.dart';

class PickupSheet extends StatelessWidget {
  final DetailController _c = Get.find();
  final MapController _controller = Get.find();
  var packageList = <Package>[];
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(4),
                    topRight: Radius.circular(4),
                  ),
                  color: Colors.white,
                ),
                margin: const EdgeInsets.only(right: 18),
                child: InkWell(
                  onTap: () {
                    if (_controller.panelOpened.value) {
                      _controller.panelOpened.value = false;
                      _controller.slideController.close();
                    } else {
                      _controller.panelOpened.value = true;
                      _controller.slideController.open();
                    }
                  },
                  child: Obx(
                    () => Icon(
                      _controller.panelOpened.value
                          ? Icons.expand_more
                          : Icons.expand_less,
                      size: 40,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Card(
                //elevation: 4,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10.0),
                    topRight: Radius.circular(10.0),
                  ),
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 10,
                  ),
                  child: Column(
                    children: [
                      // SizedBox(height: Get.height * 0.02),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.play_arrow,
                            color: Constant.blue,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            "Recorrido en curse",
                            style:
                                TextStyle(color: Constant.blue, fontSize: 14),
                          ),
                          const Spacer(),
                          Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Constant.white,
                              border: Border.all(
                                color: Constant.blue,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              "Pausar Recorrido ",
                              style:
                                  TextStyle(color: Constant.blue, fontSize: 14),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Obx(
                        () => DotStepper(
                          // direction: Axis.vertical,
                          dotCount: _c.taskDetail.value.destinations.length,
                          dotRadius: 6,

                          /// THIS MUST BE SET. SEE HOW IT IS CHANGED IN NEXT/PREVIOUS BUTTONS AND JUMP BUTTONS.
                          activeStep: _controller.activeStep.value,
                          shape: Shape.circle,
                          spacing: 16,
                          indicator: Indicator.shift,
                          lineConnectorsEnabled: true,
                          tappingEnabled: false,

                          /// TAPPING WILL NOT FUNCTION PROPERLY WITHOUT THIS PIECE OF CODE.
                          onDotTapped: (tappedDotIndex) {
                            // setState(() {
                            //   activeStep = tappedDotIndex;
                            // });
                          },

                          // DOT-STEPPER DECORATIONS
                          fixedDotDecoration: const FixedDotDecoration(
                            color: Colors.grey,
                          ),

                          indicatorDecoration: const IndicatorDecoration(
                            // style: PaintingStyle.stroke,
                            // strokeWidth: 8,
                            color: Colors.blue,
                          ),
                          lineConnectorDecoration:
                              const LineConnectorDecoration(
                            color: Colors.grey,
                            strokeWidth: 4,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 8,
                        ),
                        //height: Get.height * 0.09,
                        decoration: BoxDecoration(
                          color: Constant.lightBlue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Container(
                          // margin: EdgeInsets.only(top: 12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Obx(
                                      () => Text(
                                        "Orden ${_controller.pickupLocation[_controller.activeStep.value].order[0].code}",
                                        style: TextStyle(
                                            color: Constant.blue, fontSize: 12),
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Obx(
                                      () => Text(
                                        "Recojo ${_controller.packageInProgress.value}",
                                        style: TextStyle(
                                            color: Constant.grey, fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Obx(() => Container(
                                    child: _controller.showStart.value
                                        ? Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Paquetes",
                                                style: TextStyle(
                                                    color: Constant.blue,
                                                    fontSize: 12),
                                              ),
                                              SizedBox(
                                                  height: Get.height * 0.01),
                                              Obx(
                                                () => Text(
                                                  "Recogidos : ${_controller.checks.value}/${_controller.switchHasValue.value ? _controller.pickupLocation[_controller.activeStep.value].order[0].destinations[_controller.currentDestination.value].packages.length : "0"}",
                                                  style: TextStyle(
                                                      color: Constant.grey,
                                                      fontSize: 12),
                                                ),
                                              ),
                                            ],
                                          )
                                        : Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Tracking",
                                                style: TextStyle(
                                                    color: Constant.blue,
                                                    fontSize: 12),
                                              ),
                                              SizedBox(
                                                  height: Get.height * 0.01),
                                              InkWell(
                                                onTap: () {
                                                  _controller.showStart.value =
                                                      false;

                                                  var orderCode = _controller
                                                      .pickupLocation[
                                                          _controller
                                                              .activeStep.value]
                                                      .order[0]
                                                      .code;

                                                  var routeCode =
                                                      _c.taskDetail.value.code;

                                                  var destId = _controller
                                                      .pickupLocation[
                                                          _controller
                                                              .activeStep.value]
                                                      .order[0]
                                                      .destinations[_controller
                                                          .currentDestination
                                                          .value]
                                                      .id;

                                                  _controller.actionTask(
                                                    action: "PICKING",
                                                    context: destId,
                                                    orderCode: orderCode,
                                                    routeCode: routeCode,
                                                  );
                                                },
                                                child: Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                    horizontal: 12,
                                                    vertical: 6,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color: Constant.blue,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            24),
                                                  ),
                                                  child: Text(
                                                    "Comienzo",
                                                    style: TextStyle(
                                                        color: Constant.grey,
                                                        fontSize: 12),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                  )),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          InkWell(
                            onTap: () {},
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50),
                              ),
                              elevation: 8,
                              child: Obx(
                                () => CircleAvatar(
                                  backgroundImage: NetworkImage(
                                    _controller.switchHasValue.value
                                        ? _controller
                                            .pickupLocation[
                                                _controller.activeStep.value]
                                            .order[0]
                                            .destinations[_controller
                                                .currentDestination.value]
                                            .endPhoto
                                        : "",
                                  ),
                                  radius: 15,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Obx(
                            () => Text(
                              _controller.switchHasValue.value
                                  ? _controller
                                      .pickupLocation[
                                          _controller.activeStep.value]
                                      .order[0]
                                      .destinations[
                                          _controller.currentDestination.value]
                                      .deliveryName
                                  : "",
                              style: TextStyle(
                                  color: Constant.black, fontSize: 14),
                            ),
                          ),
                          const Spacer(),
                          InkWell(
                            onTap: () {
                              var phone = _controller
                                  .pickupLocation[_controller.activeStep.value]
                                  .order[0]
                                  .destinations[
                                      _controller.currentDestination.value]
                                  .deliveryPhoneNumber;
                              _controller.callNow(phone);
                            },
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50),
                              ),
                              elevation: 8,
                              child: CircleAvatar(
                                radius: 15,
                                backgroundColor: Constant.white,
                                child: Icon(
                                  Icons.phone,
                                  color: Constant.blue,
                                  size: 20,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          InkWell(
                            onTap: () {
                              var phone = _controller
                                  .pickupLocation[_controller.activeStep.value]
                                  .order[0]
                                  .destinations[
                                      _controller.currentDestination.value]
                                  .deliveryPhoneNumber;
                              _controller.smsNow(phone);
                            },
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50),
                              ),
                              elevation: 8,
                              child: CircleAvatar(
                                radius: 15,
                                backgroundColor: Constant.white,
                                child: Icon(
                                  Icons.chat,
                                  color: Constant.blue,
                                  size: 20,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const SizedBox(width: 8),
                          SvgPicture.asset(
                            "assets/icons/ic_pin.svg",
                            semanticsLabel: 'Package',
                            width: 28,
                            height: 28,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Obx(
                              () => Text(
                                _controller.switchHasValue.value
                                    ? _controller
                                        .pickupLocation[
                                            _controller.activeStep.value]
                                        .order[0]
                                        .destinations[_controller
                                            .currentDestination.value]
                                        .deliveryAddress
                                        .address
                                    : "",
                                style: const TextStyle(fontSize: 13),
                              ),
                            ),
                          ),
                        ],
                      ),
                      //const SizedBox(height: 12),
                      Expanded(
                        //padding: EdgeInsets.only(right: 12, left: 16),
                        child: Obx(() {
                          packageList = _controller.getPackages();
                          return ListView.separated(
                            separatorBuilder: (context, index) {
                              return Container(
                                margin: const EdgeInsets.only(
                                  left: 16,
                                  right: 8,
                                ),
                                height: 1,
                                color: Constant.lightGrey,
                              );
                            },
                            //primary: false,
                            shrinkWrap: true,
                            itemCount: _controller.switchHasValue.value
                                ? packageList.length
                                : 0,
                            itemBuilder: (BuildContext context, int index) {
                              Package destItem = packageList[index];

                              return ListTile(
                                dense: true,
                                contentPadding: const EdgeInsets.only(
                                  left: 16,
                                  right: 8,
                                  top: 0,
                                  bottom: 0,
                                ),
                                horizontalTitleGap: 8,
                                minLeadingWidth: 20,
                                minVerticalPadding: 0,
                                leading: SvgPicture.asset(
                                  "assets/icons/ic_package.svg",
                                  semanticsLabel: 'Package',
                                  width: 24,
                                  height: 24,
                                ),
                                title: Text(
                                  destItem.orderDestination,
                                  style: const TextStyle(fontSize: 12),
                                  //textDirection: TextDirection.ltr,
                                  // maxLines: 3,
                                ),
                                subtitle: Text(
                                  destItem.packageCounter,
                                  style: const TextStyle(fontSize: 12),
                                ),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: Constant.lightGrey,
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: Text(
                                        "Extra grande",
                                        style: TextStyle(
                                            color: Constant.black,
                                            fontSize: 10),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          "Recipido",
                                          style: TextStyle(
                                            color: Constant.black,
                                            fontSize: 10,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Obx(
                                          () => FlutterSwitch(
                                            width: 36.0,
                                            height: 18.0,
                                            toggleSize: 15.0,
                                            borderRadius: 30.0,
                                            padding: 2.0,
                                            onToggle: (val) {
                                              if (val) {
                                                _controller
                                                    .checksPickup[index] = true;
                                              } else {
                                                _controller
                                                        .checksPickup[index] =
                                                    false;
                                              }

                                              _controller.getSelectedPackages();

                                              var orderCode = _controller
                                                  .pickupLocation[_controller
                                                      .activeStep.value]
                                                  .order[0]
                                                  .code;
                                              var routeCode =
                                                  _c.taskDetail.value.code;

                                              // _c.actionTask(
                                              //   action: "PICKING",
                                              //   context:
                                              //       destItem.orderDestination,
                                              //   orderCode: orderCode,
                                              //   routeCode: routeCode,
                                              // );
                                            },
                                            value:
                                                _controller.switchHasValue.value
                                                    ? _controller
                                                        .checksPickup[index]
                                                    : false,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                          );
                        }),
                      ),
                      const SizedBox(height: 8),

                      InkWell(
                        onTap: () {
                          var orderCode = _controller
                              .pickupLocation[_controller.activeStep.value]
                              .order[0]
                              .code;

                          var routeCode = _c.taskDetail.value.code;

                          var destId = _controller
                              .pickupLocation[_controller.activeStep.value]
                              .order[0]
                              .destinations[
                                  _controller.currentDestination.value]
                              .id;

                          // update State on submit button
                          if (_controller.checksPickup.value.contains(false)) {
                            // Alert why not picking the package
                            var index =
                                _controller.checksPickup.value.indexOf(false);
                            if (_controller.packageStateList[index]
                                    .observation_package ==
                                null) {
                              _controller.reset.value = false;
                              Get.dialog(getDialogView(index));
                              return;
                            } else {
                              // call state api
                              _controller.submitPackages(packageList);
                              _controller.actionTask(
                                action: "IN-TRANSIT",
                                context: destId,
                                orderCode: orderCode,
                                routeCode: routeCode,
                              );
                            }
                          } else {
                            // call state api
                            _controller.submitPackages(packageList);
                            _controller.actionTask(
                              action: "IN-TRANSIT",
                              context: destId,
                              orderCode: orderCode,
                              routeCode: routeCode,
                            );
                          }

                          // // Check in the destination index if isPicup then make ShowDeliverySheet false
                          // var step = _controller.activeStep.value;
                          // var activeDestCount = _controller
                          //     .pickupLocation[step].order[0].destinations.length;

                          // if (_controller.currentDestination.value ==
                          //     activeDestCount - 1) {
                          //   if (step == _controller.pickupLocation.length - 1) {
                          //     Get.snackbar("Alert!", "Your task finished");
                          //     return;
                          //   }
                          //   _controller.currentDestination.value = 0;
                          //   _controller.activeStep.value += 1;

                          //   if (_controller
                          //       .pickupLocation[_controller.activeStep.value]
                          //       .isPickup) {
                          //     _controller.showDeliverSheet.value = false;
                          //   } else {
                          //     _controller.showDeliverSheet.value = true;
                          //   }
                          // } else {
                          //   _controller.currentDestination.value += 1;
                          // }
                          // _controller.resetProgress();
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: Constant.blue,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            "Confirm Paquetes",
                            style: TextStyle(
                              color: Constant.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        Positioned(
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
          child: Obx(() => _controller.showLoader.value
              ? Center(
                  child: SpinKitThreeBounce(
                    color: Colors.blue,
                    size: 40.0,
                  ),
                )
              : Container()),
        ),
      ],
    );
  }

  Widget getDialogView(int index) {
    var messageController = TextEditingController();
    var package = packageList[index];
    return Material(
      color: Colors.black.withOpacity(0.50),
      child: InkWell(
        onTap: (() => Get.back()),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(
              vertical: 10,
              horizontal: 16,
            ),
            width: Get.width * 0.85,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Alerta",
                  style: TextStyle(
                    color: Constant.blue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  "No se ha recibido ${package.packageCounter} paquete de este recojo, por favor indicanos la razon.",
                  style: TextStyle(
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 12),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.grey,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: TextField(
                    controller: messageController,
                    decoration: const InputDecoration(
                      hintText: "Introducir mensaje",
                      border: InputBorder.none,
                      isDense: true,
                    ),
                    minLines: 3,
                    maxLines: 3,
                  ),
                ),
                SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: InkWell(
                          onTap: () {
                            Get.back();
                            _controller.packageStateList[index]
                                .observation_package = messageController.text;

                            _controller.reset.value = true;
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 8),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: Constant.blue,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              "Enviar",
                              style: TextStyle(
                                color: Constant.white,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 12,
                    ),
                    Expanded(
                      child: Container(
                        child: InkWell(
                          onTap: () {
                            Get.back();
                            _controller.packageStateList[index]
                                .observation_package = "";
                            _controller.reset.value = true;
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 8),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Constant.blue,
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              "Skip",
                              style: TextStyle(
                                color: Constant.blue,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
