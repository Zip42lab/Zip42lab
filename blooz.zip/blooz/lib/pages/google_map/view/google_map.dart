import 'dart:io';

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/controller/detailController.dart';
import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:blooz/pages/google_map/controller/mapController.dart';
import 'package:flutter/material.dart';

import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';

import 'deliverySheet.dart';
import 'pickupSheet.dart';

class MyGoogle extends StatelessWidget {
  final _controller = Get.put(MapController());
  final DetailController _c = Get.find();

//  Completer<GoogleMapController> _controller = Completer();
  static LatLng S2_SRC = LatLng(32.096820, 76.270365);

  ///  Camera Position
  // CameraPosition MyPosition = CameraPosition(
  //     target: LatLng(32.11074689523969, 76.27862632447001), zoom: 15);

  @override
  Widget build(BuildContext context) {
    _controller.resetData();
    _controller.assignChecks(_c.taskDetail.value);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 20,
            color: Colors.black,
          ),
        ),
        title: const Text(
          'Tracking',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Obx(
              () => GoogleMap(
                mapType: MapType.normal,
                myLocationEnabled: true,
                compassEnabled: true,
                myLocationButtonEnabled: true,
                initialCameraPosition:
                    CameraPosition(target: LatLng(0.0, 0.0), zoom: 15.0),
                onMapCreated: _controller.onMapCreated,
                polylines: _controller.polylines.value,
                // onMapCreated: (GoogleMapController cont) {
                //   print("On Map created");
                //   //  _controller.complete(cont);
                // },
              ),
            ),

            /// for delivered  slidup panel

            SlidingUpPanel(
              controller: _controller.slideController,
              minHeight: MediaQuery.of(context).size.height * 0.2,
              maxHeight: MediaQuery.of(context).size.height * 0.8,
              color: Colors.transparent,
              isDraggable: false,
              parallaxEnabled: true,
              //borderRadius: radius,

              panel: Obx(() {
                return _controller.showDeliverSheet.value
                    ? DeliverySheet()
                    : PickupSheet();
              }),
            ),
          ],
        ),
      ),
    );
  }

  /// for stepper

  List<Step> stepList() => [
        const Step(
            title: Text('Account'),
            content: Center(
              child: Text('Account'),
            )),
        const Step(
            title: Text('Address'),
            content: Center(
              child: Text('Address'),
            )),
        const Step(
            title: Text('Confirm'),
            content: Center(
              child: Text('Confirm'),
            ))
      ];

  /// First sliding pannel

  /// sliding pannel for deliverd
  BorderRadiusGeometry radius = BorderRadius.only(
    topLeft: Radius.circular(24.0),
    topRight: Radius.circular(24.0),
  );
}
