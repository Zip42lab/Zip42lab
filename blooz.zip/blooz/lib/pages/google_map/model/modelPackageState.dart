class ModelPackageState {
  var verified_package = false;
  var observation_package = null;
  var package_counter = "";
  var order_destination = "";

  Map<String, dynamic> toJson() {
    return {
      'verified_package': this.verified_package,
      'observation_package': this.observation_package,
      'package_counter': this.package_counter,
      'order_destination': this.order_destination,
    };
  }
}
