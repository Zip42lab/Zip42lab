import 'dart:convert';

import 'package:blooz/pages/google_map/model/routePoint.dart';

class RouteModel {
  String id = "";
  var routeData = <RoutePoint>[];
  String from = "";
  String to = "";

  RouteModel(json) {
    if (json != null) {
      id = json['id'];
      from = json['from'];
      to = json['to'];
      var data = jsonDecode(jsonEncode(json['route_data']));
      for (int i = 0; i < data.length; i++) {
        var point = RoutePoint.fromJson(data[i]);
        routeData.add(point);
      }
    }

    Map<String, dynamic> toJson() {
      return {
        'id': this.id,
        'route_data': this.routeData,
        'from': this.from,
        'to': this.to,
      };
    }
  }
}
