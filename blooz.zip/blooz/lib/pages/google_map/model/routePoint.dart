import 'package:google_maps_flutter/google_maps_flutter.dart';

class RoutePoint {
  late LatLng source;
  late LatLng destination;
  RoutePoint();
  RoutePoint.fromJson(Map<String, dynamic> json) {
    source = LatLng.fromJson(json['source'])!;
    destination = LatLng.fromJson(json['destination'])!;
  }

  Map<String, dynamic> toJson() {
    return {
      'source': this.source,
      'destination': this.destination,
    };
  }
}
