import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Tracking extends StatelessWidget {
  const Tracking({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

bootom(context) {
  showModalBottomSheet(
      backgroundColor: Colors.white,
      context: context,
      builder: (BuildContext c) {
        return Container(
            height: Get.height * 0.20,
            child: Card(
              child: Row(
                children: [
                  SizedBox(height: Get.height * 25),
                  const Icon(
                    Icons.play_arrow,
                    size: 20,
                    color: Colors.blue,
                  )
                ],
              ),
            ));
      });
}
/*
Container(
height: 278,
child: Card(
child: Column(
children: [
SizedBox(
height: 10,
),
Row(
children: [
Column(
children: [
Text("Document"),
],
),
SizedBox(
width: 40,
height: 40,
),
Column(
children: [
CircleAvatar(
radius: 30,
backgroundColor: Colors.pink,
child: Icon(
Icons.camera_alt,
color: Colors.white,
size: 23,
),
),
Text("Camera"),
],
),
SizedBox(
width: 40,
height: 40,
),
Column(
children: [
CircleAvatar(
radius: 30,
backgroundColor: Colors.purpleAccent,
child: Icon(
Icons.insert_photo,
color: Colors.white,
size: 23,
),
),
Text("Gallery"),
],
),
],
),
SizedBox(
height: 40,
),
Row(
mainAxisAlignment: MainAxisAlignment.center,
children: [
Column(
children: [
CircleAvatar(
backgroundColor: Colors.deepOrange,
radius: 30,
child: Icon(
Icons.headset,
size: 23,
),
),
Text("Audio"),
],
),
SizedBox(
width: 40,
height: 40,
),
Column(
children: [
CircleAvatar(
radius: 30,
backgroundColor: Colors.teal,
child: Icon(
Icons.location_pin,
color: Colors.white,
size: 23,
),
),
Text("Location"),
],
),
SizedBox(
width: 40,
height: 40,
),
Column(
children: [
CircleAvatar(
radius: 30,
backgroundColor: Colors.blue,
child: Icon(
Icons.person,
color: Colors.white,
size: 23,
),
),
Text("Contact"),
],
),
],
)
],
),
),
));*/
