import 'dart:convert';

ModelHistory modelHistoryFromJson(String str) =>
    ModelHistory.fromJson(json.decode(str));

String modelHistoryToJson(ModelHistory data) => json.encode(data.toJson());

class ModelHistory {
  ModelHistory({
    required this.count,
    required this.next,
    this.previous,
    required this.results,
  });

  int count;
  String next;
  dynamic previous;
  List<HistoryResult> results;

  factory ModelHistory.fromJson(Map<String, dynamic> json) => ModelHistory(
        count: json["count"],
        next: json["next"],
        previous: json["previous"],
        results: List<HistoryResult>.from(
            json["results"].map((x) => HistoryResult.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "count": count,
        "next": next,
        "previous": previous,
        "results": List<dynamic>.from(results.map((x) => x.toJson())),
      };
}

class HistoryResult {
  HistoryResult({
    required this.code,
    required this.created,
    required this.deliveryDate,
    required this.bloozer,
    required this.deliverySchedule,
    required this.state,
    required this.totalKms,
    required this.totalTime,
    required this.totalBloozerRate,
  });

  String code;
  String created;
  DateTime deliveryDate;
  Bloozer bloozer;
  String deliverySchedule;
  String state;
  String totalKms;
  String totalTime;
  String totalBloozerRate;

  factory HistoryResult.fromJson(Map<String, dynamic> json) => HistoryResult(
        code: json["code"],
        created: json["created"],
        deliveryDate: DateTime.parse(json["delivery_date"]),
        bloozer: Bloozer.fromJson(json["bloozer"]),
        deliverySchedule: json["delivery_schedule"],
        state: json["state"],
        totalKms: json["total_kms"],
        totalTime: json["total_time"],
        totalBloozerRate: json["total_bloozer_rate"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "created": created,
        "delivery_date":
            "${deliveryDate.year.toString().padLeft(4, '0')}-${deliveryDate.month.toString().padLeft(2, '0')}-${deliveryDate.day.toString().padLeft(2, '0')}",
        "bloozer": bloozer.toJson(),
        "delivery_schedule": deliverySchedule,
        "state": state,
        "total_kms": totalKms,
        "total_time": totalTime,
        "total_bloozer_rate": totalBloozerRate,
      };
}

class Bloozer {
  Bloozer({
    required this.user,
    required this.profilePhoto,
  });

  User user;
  String profilePhoto;

  factory Bloozer.fromJson(Map<String, dynamic> json) => Bloozer(
        user: User.fromJson(json["user"]),
        profilePhoto: json["profile_photo"],
      );

  Map<String, dynamic> toJson() => {
        "user": user.toJson(),
        "profile_photo": profilePhoto,
      };
}

class User {
  User({
    required this.id,
    required this.email,
    required this.firstName,
    required this.lastName,
  });

  String id;
  String email;
  String firstName;
  String lastName;

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        email: json["email"],
        firstName: json["first_name"],
        lastName: json["last_name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email": email,
        "first_name": firstName,
        "last_name": lastName,
      };
}
