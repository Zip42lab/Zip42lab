import 'dart:convert';

List<ModelDistritos> modelDistritosFromJson(String str) =>
    List<ModelDistritos>.from(
        json.decode(str).map((x) => ModelDistritos.fromJson(x)));

String modelDistritosToJson(List<ModelDistritos> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelDistritos {
  ModelDistritos({
    required this.id,
    required this.districtName,
    required this.enabled,
    required this.city2,
  });

  int id;
  String districtName;
  bool enabled;
  City city2;

  factory ModelDistritos.fromJson(Map<String, dynamic> json) => ModelDistritos(
        id: json["id"],
        districtName: json["district_name"],
        enabled: json["enabled"],
        city2: City.fromJson(json["city2"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "district_name": districtName,
        "enabled": enabled,
        "city2": city2,
      };
}

class City {
  City({
    required this.id,
    required this.cityName,
  });

  int id;
  String cityName;

  factory City.fromJson(Map<String, dynamic> json) => City(
        id: json["id"],
        cityName: json["city_name"],
      );
}
