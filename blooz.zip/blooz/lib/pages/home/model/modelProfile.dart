// To parse this JSON data, do
//
//     final modelProfile = modelProfileFromJson(jsonString);

import 'dart:convert';

ModelProfile modelProfileFromJson(String str) =>
    ModelProfile.fromJson(json.decode(str));

String modelProfileToJson(ModelProfile data) => json.encode(data.toJson());

class ModelProfile {
  ModelProfile({
    required this.user,
  });

  ModelProfileUser user;

  factory ModelProfile.fromJson(Map<String, dynamic> json) => ModelProfile(
        user: ModelProfileUser.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "user": user.toJson(),
      };
}

class ModelProfileUser {
  ModelProfileUser({
    required this.user,
    this.city,
    this.address,
    required this.profileType,
    required this.planType,
    required this.planPrevious,
    required this.phoneNumber,
    required this.profilePhoto,
    required this.documentCode,
    required this.available,
    this.accountBank,
    this.accountNumber,
    this.accountCci,
  });

  UserUser user;
  dynamic city;
  dynamic address;
  String profileType;
  String planType;
  String planPrevious;
  String phoneNumber;
  String profilePhoto;
  String documentCode;
  bool available;
  dynamic accountBank;
  dynamic accountNumber;
  dynamic accountCci;

  factory ModelProfileUser.fromJson(Map<String, dynamic> json) =>
      ModelProfileUser(
        user: UserUser.fromJson(json["user"]),
        city: json["city"],
        address: json["address"],
        profileType: json["profile_type"],
        planType: json["plan_type"],
        planPrevious: json["plan_previous"],
        phoneNumber: json["phone_number"],
        profilePhoto: json["profile_photo"],
        documentCode: json["document_code"],
        available: json["available"],
        accountBank: json["account_bank"],
        accountNumber: json["account_number"],
        accountCci: json["account_cci"],
      );

  Map<String, dynamic> toJson() => {
        "user": user.toJson(),
        "city": city,
        "address": address,
        "profile_type": profileType,
        "plan_type": planType,
        "plan_previous": planPrevious,
        "phone_number": phoneNumber,
        "profile_photo": profilePhoto,
        "document_code": documentCode,
        "available": available,
        "account_bank": accountBank,
        "account_number": accountNumber,
        "account_cci": accountCci,
      };
}

class UserUser {
  UserUser({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.isStaff,
    required this.isSuperuser,
  });

  String id;
  String firstName;
  String lastName;
  String email;
  bool isStaff;
  bool isSuperuser;

  factory UserUser.fromJson(Map<String, dynamic> json) => UserUser(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        isStaff: json["is_staff"],
        isSuperuser: json["is_superuser"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "is_staff": isStaff,
        "is_superuser": isSuperuser,
      };
}
