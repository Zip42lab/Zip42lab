// ignore_for_file: file_names, deprecated_member_use

import 'dart:convert';

import 'package:blooz/extras/apiProvider.dart';
import 'package:blooz/pages/home/model/modelMisDistritous.dart';
import 'package:blooz/pages/home/model/modelHistory.dart';
import 'package:blooz/pages/home/model/modelProfile.dart';

import 'package:blooz/pages/home/model/modelTask.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class HomeController extends GetxController with SingleGetTickerProviderMixin {
  // final baseurl =
  //     'http://apidev.blooz.pe/api/order/routes/{code_route}/bloozer/init';

  final _provider = ApiProvider();
  late TabController tabController;
  var taskList = <Result>[].obs;
  //var profile = Rx<dynamic>(0);
  var taskInProgressList = <Result>[].obs;
  var showLoader = false.obs;
  var isAvailable = false.obs;
  var drawerPosition = 0.obs;
  var routeHistoryList = <HistoryResult>[].obs;
  late Rx<dynamic> historyDetails = Rx<dynamic>(0);
  var districtList = <ModelDistritos>[].obs;
  var assignedList = <ModelDistritos>[].obs;
  late Rx<dynamic> profile = Rx<dynamic>(0);
  var showNoData = false.obs;
  var showNoDataProgress = false.obs;
  var hideAcceptReject = true.obs;

  final storage = GetStorage();

  var dateRange = DateTimeRange(
    start: DateTime.now(),
    end: DateTime(
        DateTime.now().year, DateTime.now().month, DateTime.now().day + 30),
  ).obs;

  @override
  void onInit() {
    tabController = TabController(length: 2, initialIndex: 0, vsync: this);
    super.onInit();

    tabController.addListener(() {
      getRoutes();
    });
  }

  /// API call to get routes
  void getRoutes() {
    var data = storage.read("profile");

    ModelProfile profile = modelProfileFromJson(jsonEncode(data));
    print("PRO 2: $data");
    showLoader.value = true;
    showNoData(false);
    showNoDataProgress(false);
    _provider.getRoutes(profile.user.user.id).then((response) {
      showLoader(false);
      taskList.clear();
      taskInProgressList.clear();
      print("Total : ${response.results.length}");
      for (var element in response.results) {
        print("STATE : ${element.state}");
        if (element.state == 'IN-PROGRESS' || element.state == 'ACCEPTED') {
          taskInProgressList.add(element);
        } else {
          if (element.state == 'NEW') {
            taskList.add(element);
          }
        }
      }
      taskList.refresh();
      print("RR : ${taskList.length}");
      taskInProgressList.refresh();
      if (tabController.index == 0) {
        if (taskList.length > 0) {
          showNoData(false);
        } else {
          showNoData(true);
        }
      } else {
        if (taskInProgressList.length > 0) {
          showNoDataProgress(false);
        } else {
          showNoDataProgress(true);
        }
      }

      print("RRp : ${taskInProgressList.length}");
    }).catchError((onError) {
      print("ERERER  ::: $onError");
      showLoader(false);
      showNoData(true);
      showNoDataProgress(true);
    });
  }

/*
  void getProfileData() {
    _provider.getProfile().then((response) {
      print("then u ");
     // profile.value = response;
    }).catchError((onError) {
      print("profileError : $onError");
    });
  }*/

  void getHistoryRouteDetail(String code) {
    print(' ccc : $code');
    //showLoader.value = true;
    _provider.getRouteDetail(code).then((response) {
      historyDetails.value = response;
      historyDetails.refresh();
      showLoader.value = false;
    }).catchError((onError) {
      print("EEE : $onError");
      //showLoader.value = false;
    });
  }

  void getHistoryRoute(String date) {
    routeHistoryList.clear();
    _provider.getHistoryRouteDetail(date).then((response) {
      routeHistoryList.value = response.results;
      for (var element in response.results) {
        print("checkSTATE : ${element.state}");
      }
      print("then u ");
      // profile.value = response;
    }).catchError((onError) {
      print("Error : $onError");
    });
  }

  void getMisDistritos() {
    districtList.clear();
    _provider.getDistricts().then((response) {
      districtList.value = response;
      // districtList.removeAt(index);
      print(" check misdidtrict ");
    }).catchError((error) {
      Get.snackbar("", "$error");
    });
  }

  /// for date range

  chooseDateTimeRangePicker(String date) async {
    DateTimeRange? picked = await showDateRangePicker(
        context: Get.context!,
        firstDate: DateTime.now(),
        //firstDate: DateTime(DateTime.now().year),
        lastDate: DateTime(DateTime.now().year + 3),

        //initialDateRange: dateRange.value
        initialDateRange: dateRange.value);
    if (picked != null && picked != dateRange.value) {
      dateRange.value = picked;
    }
    getHistoryRoute(date);
  }

  /// profile

  void getProfile() {
    _provider.getProfile().then((response) {
      profile.value = response;
      print("working or not $response");
      getRoutes();
    }).catchError((error) {
      Get.snackbar("", "$error");
    });
  }

  /// accept & reject

  void acceptRejectTask(String selection, String code) {
    print("deleted");
    showLoader(true);
    _provider.acceptReject(selection, code).then((value) {
      print("deleted print(" ");");
      showLoader(false);
      hideAcceptReject(false);
      getRoutes();
    });
  }
}
