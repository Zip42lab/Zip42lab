// ignore_for_file: file_names, use_key_in_widget_constructors

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/view/routeDetail.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/model/modelTask.dart';
import 'package:blooz/pages/home/view/alertbox.dart';
import 'package:blooz/pages/home/view/selectionDialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class AssignedTasks extends StatelessWidget {
  final HomeController _conroller = Get.find();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12),
      child: Obx(() {
        var list = _conroller.taskList;
        return list.length > 0
            ? ListView.separated(
                separatorBuilder: (context, index) {
                  return Container();
                },
                itemCount: list.length,
                itemBuilder: (BuildContext context, int index) {
                  Result task = list[index];
                  print("STATUS: ${task.state}");
                  return Card(
                    elevation: 4,
                    // margin: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  "Ruta ${task.code}",
                                  style: TextStyle(
                                      color: Constant.blue, fontSize: 13),
                                ),
                              ),
                              Container(
                                child: PopupMenuButton(
                                    elevation: 20,
                                    enabled: true,
                                    onSelected: (value) {
                                      String selected = '';
                                      if (value == 0) {
                                        selected = "ACCEPTED";
                                      } else {
                                        selected = "REJECTED";
                                      }
                                      Get.dialog(SelectionDialog(
                                        selection: selected,
                                        code: task.code,
                                      ));
                                    },
                                    itemBuilder: (context) => [
                                          PopupMenuItem(
                                            child: Text("Aceptar ruta"),
                                            value: 0,
                                          ),
                                          PopupMenuItem(
                                            child: Text("Rechazar ruta"),
                                            value: 1,
                                          ),
                                        ]),
                              ), // SizedBox(width: Get.width * 0.2),
                            ],
                          ),
                          SizedBox(height: Get.height * 0.02),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/icons/ic_distance.svg",
                                          semanticsLabel: 'Package',
                                          width: 24,
                                          height: 24,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        //SizedBox(height: Get.height * 0.03),
                                        Text(
                                          '${task.totalKms}km',
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/icons/ic_time.svg",
                                          semanticsLabel: 'Package',
                                          width: 24,
                                          height: 24,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        Text(
                                          '${task.totalTime}min',
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/icons/ic_acc.svg",
                                          semanticsLabel: 'Package',
                                          width: 24,
                                          height: 24,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        Text(
                                          task.totalBloozerRate,
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.02),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.circle,
                                          size: 15,
                                          color: Constant.blue,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        Text(
                                          task.created,
                                          style: const TextStyle(
                                              fontSize: 10, color: Colors.grey),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        const Text(
                                          'Total clientes: ',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.03),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.01),
                                    Row(
                                      children: [
                                        const Text(
                                          'Total recojos:  ',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.03),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.01),
                                    Row(
                                      children: [
                                        const Text(
                                          'Total destinos:  ',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.01),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.01),
                                    Row(
                                      children: [
                                        const Text(
                                          'Total paquetes:',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.02),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            '',
                                            style: const TextStyle(
                                                fontSize: 10,
                                                color: Colors.grey),
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Get.to(RouteDetail(
                                              code: task.code,
                                              from: 0,
                                              googleDisable: 0,
                                            ));
                                          },
                                          child: Icon(
                                            Icons.arrow_forward_ios,
                                            size: 20,
                                            color: Constant.blue,
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              )
            : _conroller.showNoData.value
                ? Container(
                    alignment: Alignment.center,
                    child: const Text(
                      "No se ha asignado ninguna \ntarea nueva por ahora.",
                      textAlign: TextAlign.center,
                    ),
                  )
                : Container();
      }),
    );
  }

  void dialogBOxForSelect(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  Text('Seguro que desea rechazar \n esta ruta?',
                      style: TextStyle(color: Colors.blue, fontSize: 12),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  const Text(
                    'Esta accion no se puede deshacer',
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    children: [
                      SizedBox(width: 20),
                      InkWell(
                        onTap: () {
                          //Get.to(dialogBOxForConferm(context));
                          dialogBOxForConferm(context);
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 10, horizontal: 20),
                          decoration: Constant.myfulldecoration,
                          child: Text(
                            "Aceptar",
                            style: TextStyle(
                              color: Constant.white,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                      Spacer(),
                      Container(
                        padding:
                            EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        decoration: Constant.myfulldecoration,
                        child: Text(
                          "Cancellar",
                          style: TextStyle(
                            color: Constant.white,
                            fontSize: 12,
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  void dialogBOxForConferm(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  Container(
                    child: CircleAvatar(
                      radius: 18,
                      backgroundColor: Constant.blue,
                      child: Icon(
                        Icons.check,
                        size: 25,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.040),
                  Text('Se ha elimindo la ruta',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  // const SizedBox(height: 30),
                  SizedBox(width: 20),
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    decoration: Constant.myfulldecoration,
                    child: Text(
                      "Aceptar",
                      style: TextStyle(
                        color: Constant.white,
                        fontSize: 12,
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }
}
