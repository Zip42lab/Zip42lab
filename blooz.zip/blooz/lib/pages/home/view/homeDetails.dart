import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'assignedTasks.dart';
import 'tasksInProgress.dart';

class HomeDetail extends StatelessWidget {
  final _controller = Get.put(HomeController());
  //final model = modelProfileFromJson();

  @override
  Widget build(BuildContext context) {
    // _controller.getRoutes();

    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        toolbarHeight: 10,
        /*leading: IconButton(
          onPressed: () {
            const Drawer();
          },
          icon: Icon(Icons.menu),
          color: Colors.black,
        ),*/
        bottom: TabBar(
          indicatorColor: Constant.blue,
          labelColor: Colors.black,
          controller: _controller.tabController,
          tabs: const [
            Tab(
              text: 'Asignadas',
            ),
            Tab(
              text: 'En progreso',
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          TabBarView(
            controller: _controller.tabController,
            children: [
              AssignedTasks(),
              TaskInProgress(),
            ],
          ),
          Obx(() => _controller.showLoader.value
              ? const SpinKitThreeBounce(
                  color: Colors.blue,
                  size: 60.0,
                )
              : Container())
        ],
      ),
    );
  }
}
