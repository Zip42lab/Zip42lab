// ignore_for_file: file_names, use_key_in_widget_constructors

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/view/routeDetail.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/model/modelTask.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class TaskInProgress extends StatelessWidget {
  final HomeController _conroller = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Obx(() {
        var list = _conroller.taskInProgressList;
        return list.length > 0
            ? ListView.separated(
                separatorBuilder: (context, index) {
                  return const SizedBox(
                    height: 8,
                  );
                },
                itemCount: list.length,
                itemBuilder: (BuildContext context, int index) {
                  Result task = list[index];
                  return Card(
                    elevation: 4,
                    // margin: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  "Ruta ${task.code}",
                                  style: TextStyle(
                                      color: Constant.blue, fontSize: 13),
                                ),
                              ),
                              // SizedBox(width: Get.width * 0.2),
                            ],
                          ),
                          SizedBox(height: Get.height * 0.02),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/icons/ic_distance.svg",
                                          semanticsLabel: 'Package',
                                          width: 24,
                                          height: 24,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        //SizedBox(height: Get.height * 0.03),
                                        Text(
                                          '${task.totalKms}km',
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/icons/ic_time.svg",
                                          semanticsLabel: 'Package',
                                          width: 24,
                                          height: 24,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        Text(
                                          '${task.totalTime}min',
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/icons/ic_acc.svg",
                                          semanticsLabel: 'Package',
                                          width: 24,
                                          height: 24,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        Text(
                                          task.totalBloozerRate,
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.02),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.circle,
                                          size: 15,
                                          color: Constant.blue,
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        Text(
                                          task.created,
                                          style: const TextStyle(
                                              fontSize: 10, color: Colors.grey),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        const Text(
                                          'Total clientes: ',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.03),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.01),
                                    Row(
                                      children: [
                                        const Text(
                                          'Total recojos:  ',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.03),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.01),
                                    Row(
                                      children: [
                                        const Text(
                                          'Total destinos:  ',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.01),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.01),
                                    Row(
                                      children: [
                                        const Text(
                                          'Total paquetes:',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        const Text(
                                          'NA',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.02),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            '',
                                            style: const TextStyle(
                                                fontSize: 10,
                                                color: Colors.grey),
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Get.to(RouteDetail(
                                              code: task.code,
                                              from: 1,
                                              googleDisable: 0,
                                            ));
                                          },
                                          child: Icon(
                                            Icons.arrow_forward_ios,
                                            size: 20,
                                            color: Constant.blue,
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              )
            : _conroller.showNoDataProgress.value
                ? Container(
                    alignment: Alignment.center,
                    child: const Text(
                      "No hay tareas \nen curso.",
                      textAlign: TextAlign.center,
                    ),
                  )
                : Container();
      }),
    );
  }
}
