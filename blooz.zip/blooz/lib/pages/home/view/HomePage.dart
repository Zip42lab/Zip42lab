import 'package:blooz/extras/apiProvider.dart';
import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/view/drawer/historyRoute/view/historial%20de%20rutas.dart';
import 'package:blooz/pages/home/view/drawer/mis%20distritos.dart';
import 'package:blooz/pages/home/view/drawer/myaccount/view/myaccount.dart';
import 'package:blooz/pages/home/view/homeDetails.dart';
import 'package:blooz/pages/login/view/login_page/loginPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class HomePage extends StatelessWidget {
  final _controller = Get.put(HomeController());
  // final _provider = ApiProvider();
  final storage = GetStorage();

  @override
  Widget build(BuildContext context) {
    _controller.getProfile();
    _controller.taskInProgressList.clear();
    _controller.taskList.clear();
    // _controller.actionTask(choose, code);
    return Scaffold(
      appBar: AppBar(
        // actions: [
        //   Icon(
        //     Icons.access_time,
        //     color: Constant.white,
        //     size: 30,
        //   )
        // ],
        title: Obx(
          () => appBarText(_controller.drawerPosition.value),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      drawer: Drawer(
        // backgroundColor: Constant.white,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              Container(
                height: Get.height * 0.30,
                child: DrawerHeader(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 100,
                        width: 100,
                        margin: EdgeInsets.only(top: 10),
                        child: ClipOval(
                          //  radius: 50.0,

                          child: Obx(() => _controller.profile.value == 0
                              ? Image.network(
                                  //_controller.profile.value.user.profilePhoto,

                                  'https://larasys.cl/wp-content/uploads/2019/05/people-3.png',
                                  fit: BoxFit.cover,
                                )
                              : Image.network(
                                  _controller.profile.value.user.profilePhoto,

                                  // 'https://larasys.cl/wp-content/uploads/2019/05/people-3.png',
                                  fit: BoxFit.cover,
                                )),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.only(top: 10),
                          child: Center(
                            child: Obx(
                              () => Text(
                                //"ghg",
                                "${_controller.profile.value.user.user.firstName} ${_controller.profile.value.user.user.lastName}",
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                            ),
                          )),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 12,
                width: 12,
              ),
              Obx(
                () => Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: _controller.drawerPosition.value == 0
                        ? Constant.lightBlue
                        : Constant.white,
                  ),
                  child: ListTile(
                    selectedColor: Constant.black,
                    selected:
                        _controller.drawerPosition.value == 0 ? true : false,
                    dense: true,
                    visualDensity: VisualDensity(vertical: -1),
                    title: const Text("Mis rutas"),
                    onTap: () {
                      _controller.drawerPosition.value = 0;
                      Get.back();
                    },
                  ),
                ),
              ),
              Obx(
                () => Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: _controller.drawerPosition.value == 1
                        ? Constant.lightBlue
                        : Constant.white,
                    // color: Constant.blue,
                  ),
                  child: ListTile(
                    dense: true,
                    selectedColor: Constant.black,
                    selected:
                        _controller.drawerPosition.value == 1 ? true : false,
                    visualDensity: VisualDensity(vertical: -1),
                    title: const Text("Historial de rutas"),
                    onTap: () {
                      _controller.drawerPosition.value = 1;
                      Get.back();
                    },
                  ),
                ),
              ),
              Obx(
                () => Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: _controller.drawerPosition.value == 2
                        ? Constant.lightBlue
                        : Constant.white,
                    // color: Constant.blue,
                  ),
                  child: ListTile(
                    selectedColor: Constant.black,
                    selected:
                        _controller.drawerPosition.value == 2 ? true : false,
                    dense: true,
                    visualDensity: VisualDensity(vertical: -1),
                    title: const Text("Mis distritos"),
                    onTap: () {
                      _controller.drawerPosition.value = 2;
                      Get.back();
                    },
                  ),
                ),
              ),
              Obx(
                () => Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: _controller.drawerPosition.value == 3
                        ? Constant.lightBlue
                        : Constant.white,
                    // color: Constant.blue,
                  ),
                  child: ListTile(
                    selectedColor: Constant.black,
                    selected:
                        _controller.drawerPosition.value == 3 ? true : false,
                    dense: true,
                    visualDensity: VisualDensity(vertical: -1),
                    title: Text("Mi cuenta"),
                    onTap: () {
                      _controller.drawerPosition.value = 3;
                      Get.back();
                    },
                  ),
                ),
              ),
              const SizedBox(height: 223),
              Row(
                children: [
                  Container(
                    margin: const EdgeInsets.all(12),
                    child: const Text(
                      "Desposible",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Obx(() => FlutterSwitch(
                          width: 60.0,
                          height: 28.0,
                          toggleSize: 15.0,
                          borderRadius: 30.0,
                          padding: 5.0,
                          onToggle: (val) {
                            _controller.isAvailable.value = val;
                          },
                          value: _controller.isAvailable.value,
                          showOnOff: true,
                        )),
                  ),
                ],
              ),
              InkWell(
                onTap: () {
                  storage.erase();
                  Get.offAll(LoginPage());

                  // _provider.checkLogin() ? LoginPage() : HomePage();
                },
                child: Container(
                  margin: const EdgeInsets.all(12),
                  child: const Text(
                    "cerrer sesion",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Obx(
          () => Container(
            //padding: EdgeInsets.symmetric(vertical: 10),
            child: drawerList(_controller.drawerPosition.value),
          ),
        ),
      ),
    );
  }

  Widget drawerList(int index) {
    if (index == 0) {
      return HomeDetail();
    } else if (index == 1) {
      return RouteHistory(
        date: _controller.dateRange.value.toString(),
      );
    } else if (index == 2) {
      return MyDistricts();
    } else if (index == 3) {
      return MyAccount();
    }
    return HomeDetail();
  }

  Widget appBarText(int index) {
    if (index == 0) {
      return Text(
        "Rutas",
        style: TextStyle(color: Constant.black),
      );
    } else if (index == 1) {
      return Text(
        "Historial de rutas",
        style: TextStyle(color: Constant.black),
      );
    } else if (index == 2) {
      return Text(
        "Mis Distritos",
        style: TextStyle(color: Constant.black),
      );
    } else if (index == 3) {
      return Text(
        "Mi Cuenta",
        style: TextStyle(color: Constant.black),
      );
    }
    return Text(
      "Rutas",
      style: TextStyle(color: Constant.black),
    );
  }
}
