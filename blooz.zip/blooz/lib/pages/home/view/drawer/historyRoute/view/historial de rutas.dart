import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/view/routeDetail.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/model/modelHistory.dart';
import 'package:blooz/pages/home/view/drawer/historyRoute/view/historyRouteDetails.dart';
import 'package:blooz/pages/home/view/drawer/historyRoute/view/historysearch.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class RouteHistory extends StatelessWidget {
  final controller = Get.put(HomeController());
  final String date;

  RouteHistory({Key? key, required this.date}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    controller.getHistoryRoute(date);

    return Scaffold(
      body: SafeArea(
        child: Container(
            child: Column(
          children: [
            /* Container(
              padding: EdgeInsets.all(8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: Icon(
                      Icons.arrow_back_ios,
                      size: 20,
                      color: Constant.blue,
                    ),
                  ),
                  Text("Informacion personal"),
                ],
              ),
            ),*/
            InkWell(
              onTap: () {
                controller.chooseDateTimeRangePicker(date);
              },
              child: Container(
                height: 48,
                margin: const EdgeInsets.only(top: 15.0, left: 15, right: 15),
                padding: const EdgeInsets.all(3.0),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: Colors.black54)),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        /* showSearch(
                                context: context, delegate: HistorySearch());*/
                      },
                      icon: Icon(Icons.search),
                    ),
                    Expanded(
                      child: Obx(
                        () => Text(
                            "${DateFormat("dd, MMM yyyy").format(controller.dateRange.value.start)} - ${DateFormat("dd, MMM yyyy").format(controller.dateRange.value.end)}"),

                        /*Text
                            DateFormat("dd,MM,yyyy")
                                .format(controller.dateRange.value.start),
                          ),*/
                      ),
                    ),
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () {
                //showSearch(context: context, delegate: HistorySearch());
              },
              child: Container(
                  height: 48,
                  margin: const EdgeInsets.only(top: 15.0, left: 15, right: 15),
                  padding: const EdgeInsets.all(3.0),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.black54)),
                  child: Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 10, right: 12),
                        child: Icon(Icons.search),
                      ),
                      // icon: Icon(Icons.search),
                      Expanded(
                          child: TextField(
                        decoration: InputDecoration(
                            border: InputBorder.none, hintText: 'Buscar por'),
                      )),
                    ],
                  )),
            ),
            Expanded(
              child: Obx(() {
                return ListView.builder(
                    itemCount: controller.routeHistoryList.length,
                    itemBuilder: (context, index) {
                      HistoryResult task = controller.routeHistoryList[index];
                      return Card(
                        elevation: 4,
                        // margin: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      "Ruta ${task.code}",
                                      style: TextStyle(
                                          color: Constant.blue, fontSize: 13),
                                    ),
                                  ),
                                  // SizedBox(width: Get.width * 0.2),
                                ],
                              ),
                              SizedBox(height: Get.height * 0.02),
                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            SvgPicture.asset(
                                              "assets/icons/ic_distance.svg",
                                              semanticsLabel: 'Package',
                                              width: 24,
                                              height: 24,
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            //SizedBox(height: Get.height * 0.03),
                                            Text(
                                              '${task.totalKms}km',
                                              style:
                                                  const TextStyle(fontSize: 14),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8),
                                        Row(
                                          children: [
                                            SvgPicture.asset(
                                              "assets/icons/ic_time.svg",
                                              semanticsLabel: 'Package',
                                              width: 24,
                                              height: 24,
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            Text(
                                              '${task.totalTime}min',
                                              style:
                                                  const TextStyle(fontSize: 14),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8),
                                        Row(
                                          children: [
                                            SvgPicture.asset(
                                              "assets/icons/ic_acc.svg",
                                              semanticsLabel: 'Package',
                                              width: 24,
                                              height: 24,
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            Text(
                                              task.totalBloozerRate,
                                              style:
                                                  const TextStyle(fontSize: 14),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: Get.height * 0.02),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.circle,
                                              size: 15,
                                              color: Constant.blue,
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            Text(
                                              task.created,
                                              style: const TextStyle(
                                                  fontSize: 10,
                                                  color: Colors.grey),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            const Text(
                                              'Total clientes: ',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                            SizedBox(width: Get.width * 0.03),
                                            const Text(
                                              '3',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: Get.height * 0.01),
                                        Row(
                                          children: [
                                            const Text(
                                              'Total recojos:  ',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                            SizedBox(width: Get.width * 0.03),
                                            const Text(
                                              '3',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: Get.height * 0.01),
                                        Row(
                                          children: [
                                            const Text(
                                              'Total destinos:  ',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                            SizedBox(width: Get.width * 0.01),
                                            const Text(
                                              '9',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: Get.height * 0.01),
                                        Row(
                                          children: [
                                            const Text(
                                              'Total paquetes:',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            const Text(
                                              '16',
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: Get.height * 0.02),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                '',
                                                style: const TextStyle(
                                                    fontSize: 10,
                                                    color: Colors.grey),
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                Get.to(RouteDetail(
                                                  code: task.code,
                                                  from: 1,
                                                  googleDisable: 1,
                                                ));
                                              },
                                              child: Icon(
                                                Icons.arrow_forward_ios,
                                                size: 20,
                                                color: Constant.blue,
                                              ),
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    });
              }),
            )
          ],
        )),
      ),
    );
  }
}
