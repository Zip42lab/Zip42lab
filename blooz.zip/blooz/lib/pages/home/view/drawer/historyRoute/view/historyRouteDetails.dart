// ignore_for_file: use_key_in_widget_constructors, avoid_print, file_names

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/details/controller/detailController.dart';
import 'package:blooz/pages/details/model/modelTaskDetail.dart';
import 'package:blooz/pages/google_map/view/google_map.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:fluttertoast/fluttertoast.dart';

class HistoryRouteDetails extends StatelessWidget {
  final _controller = Get.put(HomeController());
  final String code;

  HistoryRouteDetails({Key? key, required this.code}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    /// get route detail api call
    _controller.getHistoryRouteDetail(code);

    /// end

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: InkWell(
          onTap: () {
            Get.back();
          },
          child: const Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
        title: const Text(
          'Detalle de la Route',
          style: TextStyle(color: Colors.black),
        ),
        // iconTheme: const IconThemeData(color: Colors.blue),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            child: ListView(
              scrollDirection: Axis.vertical,
              children: [
                Card(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Ruta76756765',
                          style: const TextStyle(
                            color: Colors.blue,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            Text(
                              "check,",
                              style: TextStyle(fontSize: 10),
                            ),
                            SizedBox(width: Get.width * 0.01),
                            Text(
                              "07 July 2020",
                              style: TextStyle(fontSize: 10),
                            ),
                            SizedBox(width: Get.width * 0.01),
                            Text(
                              "12:37 pm",
                              style: TextStyle(fontSize: 10),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 5,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      // mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Clientes',
                                style: TextStyle(fontSize: 18),
                                //textAlign: TextAlign.end,
                              ),
                              Container(
                                height: 10,
                              ),
                              ListView.separated(
                                primary: false,
                                shrinkWrap: true,
                                itemCount: 4,
                                separatorBuilder: (context, index) {
                                  return const SizedBox(
                                    height: 8,
                                  );
                                },
                                itemBuilder: (context, index) {
                                  return Row(
                                    children: [
                                      CircleAvatar(
                                        radius: 20,
                                        backgroundColor: Constant.pink,
                                        backgroundImage: NetworkImage(""),
                                      ),
                                      SizedBox(width: Get.width * 0.03),
                                      Text(
                                        "name",
                                        style: TextStyle(fontSize: 15),
                                      ),
                                    ],
                                  );
                                },
                              )
                            ],
                          ),
                        ),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                'info general',
                                style: TextStyle(fontSize: 18),
                                //textAlign: TextAlign.end,
                              ),
                              Container(
                                height: 10,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircleAvatar(
                                    radius: 10,
                                    backgroundColor: Constant.white,
                                    child: Icon(
                                      Icons.location_pin,
                                      size: 25,
                                      color: Constant.blue,
                                    ),
                                  ),
                                  SizedBox(width: Get.width * 0.02),
                                  Text(
                                    "name",
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                              SizedBox(height: Get.height * 0.01),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircleAvatar(
                                    radius: 10,
                                    backgroundColor: Constant.white,
                                    child: Icon(
                                      Icons.done,
                                      color: Constant.blue,
                                      size: 25,
                                    ),
                                  ),
                                  SizedBox(width: Get.width * 0.02),
                                  Text(
                                    "name",
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                              SizedBox(height: Get.height * 0.01),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircleAvatar(
                                    radius: 10,
                                    backgroundColor: Constant.white,
                                    child: Icon(
                                      Icons.error,
                                      color: Constant.blue,
                                      size: 25,
                                    ),
                                  ),
                                  SizedBox(width: Get.width * 0.02),
                                  Text(
                                    "name",
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Row(
                          children: const [
                            Text(
                              'Paquetes',
                              style: TextStyle(fontSize: 13),
                            ),
                          ],
                        ),
                        SizedBox(height: Get.height * 0.010),
                        ListView.separated(
                          primary: false,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return Row(children: [
                              const SizedBox(width: 0),
                              Center(
                                child: Icon(
                                  Icons.add_to_photos,
                                  color: Constant.blue,
                                ),
                              ),
                              SizedBox(width: Get.width * 0.02),
                              Text(
                                "name",
                                style: TextStyle(fontSize: 12),
                              ),
                            ]);
                          },
                          separatorBuilder: (context, index) {
                            return const SizedBox(height: 8);
                          },
                          itemCount: 3,
                        )
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 8,
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: const Text(
                            "Resumen del recorrido",
                            style: TextStyle(color: Colors.black, fontSize: 15),
                          ),
                        ),
                        Container(
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.only(bottom: 20),
                            child: ListView.builder(
                                primary: false,
                                shrinkWrap: true,
                                itemCount: 5,
                                itemBuilder: (BuildContext context, int index) {
                                  // var destItem = destinations[index];
                                  return Container(
                                    padding: const EdgeInsets.all(3),
                                    child: Row(
                                      children: [
                                        Column(
                                          //crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Icon(
                                              Icons.location_pin,
                                              size: 32,
                                              color: Constant.blue,
                                            ),
                                            DottedLine(
                                              direction: Axis.vertical,
                                              lineLength: Get.height * 0.12,
                                              lineThickness: 1.0,
                                              dashLength: 4.0,
                                              dashColor: Colors.black,
                                              dashRadius: 0.0,
                                              dashGapLength: 4.0,
                                              dashGapColor: Colors.transparent,
                                              dashGapRadius: 0.0,
                                            )
                                          ],
                                        ),
                                        SizedBox(width: Get.width * 0.02),
                                        // width: Get.width * 0.9,
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "fffggfgffjhfjh",
                                                style: const TextStyle(
                                                    fontSize: 14),
                                              ),
                                              SizedBox(
                                                  height: Get.height * 0.02),
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.person,
                                                    size: 20,
                                                    color: Constant.grey,
                                                  ),
                                                  SizedBox(
                                                      width: Get.width * 0.02),
                                                  Text(
                                                    "gcfxdfgdfg",
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        color: Constant.grey),
                                                  )
                                                ],
                                              ),
                                              const SizedBox(height: 8),
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.phone,
                                                    size: 20,
                                                    color: Constant.grey,
                                                  ),
                                                  SizedBox(
                                                      width: Get.width * 0.02),
                                                  Text(
                                                    "vhjghghghghj",
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        color: Constant.grey),
                                                  )
                                                ],
                                              ),
                                              const SizedBox(height: 8),
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.crop_square_outlined,
                                                    size: 20,
                                                    color: Constant.grey,
                                                  ),
                                                  SizedBox(
                                                      width: Get.width * 0.02),
                                                  Text(
                                                    "hgghg",
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        color: Constant.grey),
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                })),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          /*Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            child: Obx(() => _controller.showLoader.value
                ? Container(
              color: Colors.white,
              child: const Center(
                child: SpinKitThreeBounce(
                  color: Colors.blue,
                  size: 40.0,
                ),
              ),
            )
                : Container()),
          ),*/
        ],
      ),
    );
  }

  void dialogBOxForSelect(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  const Text('Seguro que desea rechazar \n esta ruta?',
                      style: TextStyle(color: Colors.blue, fontSize: 12),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  const Text(
                    'Esta accion no se puede deshacer',
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    children: [
                      const SizedBox(width: 20),
                      InkWell(
                        onTap: () {
                          //Get.to(dialogBOxForConferm(context));
                          dialogBOxForConferm(context);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 20),
                          decoration: Constant.myfulldecoration,
                          child: Text(
                            "Aceptar",
                            style: TextStyle(
                              color: Constant.white,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                      Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 20),
                        decoration: Constant.myfulldecoration,
                        child: Text(
                          "Cancellar",
                          style: TextStyle(
                            color: Constant.white,
                            fontSize: 12,
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  void dialogBOxForConferm(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  Container(
                    child: CircleAvatar(
                      radius: 18,
                      backgroundColor: Constant.blue,
                      child: const Icon(
                        Icons.check,
                        size: 25,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.040),
                  const Text('Se ha elimindo la ruta',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  // const SizedBox(height: 30),
                  const SizedBox(width: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 20),
                    decoration: Constant.myfulldecoration,
                    child: Text(
                      "Aceptar",
                      style: TextStyle(
                        color: Constant.white,
                        fontSize: 12,
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }
}
