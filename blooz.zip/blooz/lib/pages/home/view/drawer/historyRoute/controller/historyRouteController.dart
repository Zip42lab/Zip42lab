import 'package:get/get.dart';

class HistoryRouteController extends GetxController {}
