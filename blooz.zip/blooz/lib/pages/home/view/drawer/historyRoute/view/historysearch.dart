import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HistorySearch extends SearchDelegate<String>{

  final names = [
    'Kartik',
    'Prashar',
    'fidsjif','djfiodsjf','ahsiuj','sdfafjio',
  ];
   late final recentNames = ['Kartik','prashar'];

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [IconButton(onPressed: (){}, icon: Icon(Icons.clear))];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    // TODO: implement buildLeading
    return IconButton(onPressed: (){
      Get.back();
    }, icon: Icon(Icons.arrow_back_ios));
  }

  @override
  Widget buildResults(BuildContext context) {
    // TODO: implement buildResults
    throw UnimplementedError();
  }

  @override
  Widget buildSuggestions(BuildContext context) {

    final suggestionList = /*query.isEmpty ? recentNames =*/ names;
    // TODO: implement buildSuggestions
    return ListView.builder(
        itemCount: 6,
        itemBuilder: (context , index) => ListTile(
      title: Text(suggestionList[index] ),
    ));
  }
  
  
}