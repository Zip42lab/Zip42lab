import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/model/modelMisDistritous.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/state_manager.dart';

class MyDistricts extends StatelessWidget {
  final _controller = Get.put(HomeController());
  //const MyDistricts({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    _controller.getMisDistritos();
    return Scaffold(
      /* appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(Icons.arrow_back_ios),
          color: Colors.black,
        ),
        title: const Text(
          'Mis Distritos',
          style: TextStyle(color: Colors.black),
        ),
      ),*/
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: ListView(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            children: [
              TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  prefixIcon: Icon(Icons.search),
                  hintText: "Buscar distrito",
                  hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                  isDense: true,
                ),
                keyboardType: TextInputType.text,
              ),
              Container(
                margin: EdgeInsets.only(top: 10, bottom: 10, left: 10),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    'Asignados',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
              Obx(() => ListView.separated(
                    physics: ClampingScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (context, index) {
                      return Container(
                        height: 2,
                      );
                    },
                    itemCount: _controller.assignedList.length,
                    itemBuilder: (BuildContext context, int index) {
                      var model = _controller.assignedList[index];
                      return Card(
                        color: Constant.lightBlue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: ListTile(
                          leading: SvgPicture.asset(
                            "assets/icons/misDistritos.svg",
                            semanticsLabel: 'Package',
                            width: 24,
                            height: 24,
                          ),
                          title: Text(model.districtName),
                          trailing: InkWell(
                              onTap: () {
                                _controller.assignedList.removeAt(index);
                                _controller.districtList.add(model);
                              },
                              child: CircleAvatar(
                                  backgroundColor: Constant.skyblue,
                                  radius: 10,
                                  child: Icon(
                                    Icons.clear,
                                    size: 14,
                                  ))),
                        ),
                      );
                    },
                  )),
              Container(
                margin: EdgeInsets.only(top: 10, bottom: 10, left: 10),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    'No asignados',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
              Obx(
                () => ListView.separated(
                  physics: ClampingScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) {
                    return Container(
                      height: 2,
                    );
                  },
                  itemCount: _controller.districtList.length,
                  itemBuilder: (BuildContext context, int index) {
                    ModelDistritos task = _controller.districtList[index];
                    return InkWell(
                      onTap: () {
                        _controller.districtList.removeAt(index);
                        _controller.assignedList.add(task);
                      },
                      child: Card(
                        color: Constant.lightBlue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: ListTile(
                          leading: SvgPicture.asset(
                            "assets/icons/misDistritos.svg",
                            semanticsLabel: 'Package',
                            width: 24,
                            height: 24,
                          ),
                          //title: Obx(() => Text(task.city2.cityName)),
                          title: Text(task.districtName),
                          // trailing: Icon(Icons.cancel),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
