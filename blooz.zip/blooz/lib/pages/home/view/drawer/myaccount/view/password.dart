import 'package:blooz/extras/constants.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Password extends StatelessWidget {
  const Password({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            children: [
              Expanded(
                  child: ListView(
                physics: NeverScrollableScrollPhysics(),
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            Get.back();
                          },
                          icon: Icon(
                            Icons.arrow_back_ios,
                            size: 20,
                            color: Constant.blue,
                          ),
                        ),
                        Text("Contrasena"),
                      ],
                    ),
                  ),
                  Container(
                    child: Padding(
                      padding: EdgeInsets.all(15),
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Mi contrasena',
                              style: TextStyle(color: Constant.blue),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          SizedBox(height: Get.height * 0.03),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'contrasena actual',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),

                          /*Padding(
                            padding: EdgeInsets.all(4),
                            child: TextField(
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                hintText: "Carlos Smith",
                              ),
                              keyboardType: TextInputType.text,
                            ),
                          ),*/
                          /*Row(
                            children: [
                              Text(
                                'COMPLAINT',
                                style: TextStyle(
                                    color: Colors.black54,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: 110,
                              ),
                              Container(
                                child: DropdownButton<String>(
                                  value: dropdownValue,
                                  icon: const Icon(Icons.arrow_downward),
                                  elevation: 16,
                                  style:
                                      const TextStyle(color: Colors.deepPurple),
                                  underline: Container(
                                    height: 2,
                                    color: Colors.deepPurpleAccent,
                                  ),
                                  onChanged: (String? newValue) {
                                    (() {
                                      dropdownValue = newValue!;
                                    });
                                  },
                                  items: <String>[
                                    'One',
                                    'Two',
                                    'Free',
                                    'Four'
                                  ].map<DropdownMenuItem<String>>((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ],
                          ),*/
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "Ingresa tu contrasena",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          /*DropdownButton<String>(
                            value: dropdownValue,
                            icon: const Icon(Icons.arrow_downward),
                            elevation: 16,
                            style: const TextStyle(color: Colors.deepPurple),
                            underline: Container(
                              height: 2,
                              color: Colors.deepPurpleAccent,
                            ),
                            onChanged: (String? newValue) {
                              (() {
                                dropdownValue = newValue!;
                              });
                            },
                            items: <String>['One', 'Two', 'Free', 'Four']
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),*/
                          SizedBox(height: Get.height * 0.035),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Nueva contrasena',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "Ingresa tu contrasena",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          SizedBox(height: Get.height * 0.035),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Confirmar contrasena',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "Ingresa tu contrasena",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          SizedBox(
                            height: Get.height * 0.075,
                          ),
                          Container(
                            height: 40,
                            width: 160,
                            decoration: Constant.myfulldecoration,
                            //alignment: Alignment.center,
                            // alignment: Alignment.center,
                            child: InkWell(
                              onTap: () {
                                dialogBOxForConferm(context);
                              },
                              child: Center(
                                child: Text(
                                  " Guardar ",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ))
            ],
          ),
        ),
      ),
    );
  }

  void dialogBOxForConferm(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  SizedBox(height: Get.height * 0.03),
                  Container(
                    child: CircleAvatar(
                      radius: 30,
                      backgroundColor: Constant.blue,
                      child: const Icon(
                        Icons.check,
                        size: 35,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.040),
                  const Text('!Se han guardado',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  const Text('ios cambios!',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  // const SizedBox(height: 30),
                  const SizedBox(width: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 20),
                    decoration: Constant.myfulldecoration,
                    child: Text(
                      "Aceptar",
                      style: TextStyle(
                        color: Constant.white,
                        fontSize: 12,
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }
}
