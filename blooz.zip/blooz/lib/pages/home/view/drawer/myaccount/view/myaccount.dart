import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/view/drawer/myaccount/mycontroller/MiController.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

import 'Personal Information.dart';
import 'password.dart';
import 'paymentdetails.dart';
import 'vehicledata.dart';

class MyAccount extends StatelessWidget {
  final _controller = Get.put(MyController());
  final HomeController _ctrl = Get.find();
  MyAccount({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // _controller.getProfile();
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: Get.width,
          child: Column(children: [
            /*Container(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: Icon(
                      Icons.arrow_back_ios,
                      size: 20,
                      color: Constant.blue,
                    ),
                  ),
                  const Text("Mi Cuenta"),
                ],
              ),
            ),*/
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  child: Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(5),
                          child: Stack(
                            children: [
                              Obx(
                                () => Container(
                                  child: CircleAvatar(
                                    radius: 50,
                                    backgroundColor: Colors.white,
                                    child: Image.network(
                                      _ctrl.profile.value.user.profilePhoto,
                                      //"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRB_mpdTkAOjNZ8_N9SNFkzq7XCHXP81acoXPoHCRNi1o7IQk3EMPXwcA7kEVjw9jMHXos&usqp=CAU",

                                      width: 80,
                                      height: 80,
                                    ),
                                  ),
                                ),
                              ),
                              /* const Positioned(
                                bottom: 0,
                                right: 0,
                                child: CircleAvatar(
                                  backgroundColor: Colors.white,
                                  radius: 12,
                                  child: Icon(Icons.camera_alt),
                                ),
                              ),*/
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    child: Obx(
                                      () => Text(
                                        //"ghg",
                                        "${_ctrl.profile.value.user.user.firstName} ${_ctrl.profile.value.user.user.lastName}",
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: Get.width * 0.008,
                                    width: Get.height * 0.2,
                                  ),
                                  Container(
                                    child: RatingBar.builder(
                                      initialRating: 3,
                                      minRating: 1,
                                      itemSize: 17,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 5,
                                      itemPadding:
                                          EdgeInsets.symmetric(horizontal: 4.0),
                                      itemBuilder: (context, _) => Icon(
                                        Icons.star,
                                        color: Colors.amber,
                                      ),
                                      onRatingUpdate: (rating) {
                                        print(rating);
                                      },
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(top: 10),
                                    child: Text(
                                      // _ctrl.profile.value.user.documentCode,
                                      "128 rutas atendidas",
                                      style: TextStyle(fontSize: 10),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Container(
                      padding: const EdgeInsets.only(left: 20, top: 10),
                      height: 60,
                      width: Get.width,
                      child: InkWell(
                        onTap: () {
                          /* Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PersonalInformation()),
                          );*/
                          Get.to(PersonalInformation());
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Information Personal,",
                              style: TextStyle(fontSize: 13),
                            ),
                            Row(
                              children: const [
                                Expanded(
                                    child: Text(
                                  "Tu nombro",
                                  style: TextStyle(
                                      color: Colors.black38, fontSize: 13),
                                )),
                                SizedBox(
                                  width: 8,
                                ),
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 20, color: Colors.black38),
                                SizedBox(
                                  width: 20,
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Container(
                      padding: EdgeInsets.only(left: 20, top: 10),
                      height: 60,
                      width: Get.width,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PaymentDetails()),
                          );
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Datos de pago",
                              style: TextStyle(fontSize: 13),
                            ),
                            Row(
                              children: const [
                                Expanded(
                                    child: Text(
                                  "Banco, nro. de cuenta, CCI",
                                  style: TextStyle(
                                      color: Colors.black38, fontSize: 13),
                                )),
                                SizedBox(
                                  width: 8,
                                ),
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 20, color: Colors.black38),
                                SizedBox(
                                  width: 20,
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Container(
                      padding: EdgeInsets.only(left: 20, top: 10),
                      height: 60,
                      width: Get.width,
                      child: InkWell(
                        onTap: () {
                          Get.to(VehicleData());
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Datos de vehiculo",
                              style: TextStyle(fontSize: 13),
                            ),
                            Row(
                              children: const [
                                Expanded(
                                    child: Text(
                                  "Tipo, marca, modelo, ano, place...",
                                  style: TextStyle(
                                      color: Colors.black38, fontSize: 13),
                                )),
                                SizedBox(
                                  width: 8,
                                ),
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 20, color: Colors.black38),
                                SizedBox(
                                  width: 20,
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Container(
                      padding: const EdgeInsets.only(left: 20, top: 10),
                      height: 60,
                      width: Get.width,
                      child: InkWell(
                        onTap: () {
                          /*Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Password()),
                      );*/
                          Get.to(const Password());
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Contrasena",
                              style: TextStyle(fontSize: 13),
                            ),
                            Row(
                              children: const [
                                Expanded(
                                    child: Text(
                                  "Actualize tu contraasena",
                                  style: TextStyle(
                                      color: Colors.black38, fontSize: 13),
                                )),
                                SizedBox(
                                  width: 8,
                                ),
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 20, color: Colors.black38),
                                SizedBox(
                                  width: 20,
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            )
          ]),
        ),
      ),
    );
  }
}
