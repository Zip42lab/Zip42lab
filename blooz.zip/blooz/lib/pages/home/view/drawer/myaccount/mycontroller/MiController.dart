import 'dart:io';

import 'package:blooz/extras/apiProvider.dart';
import 'package:blooz/pages/home/model/modelProfile.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';

class MyController extends GetxController {
  final _provider = ApiProvider();
  var selectImage = File("").obs;
  var isAvailable = false.obs;
  var owns = false.obs;
  var storage = GetStorage();
  // var profile = ModelProfile().obs;

  var current = false.obs;
  List<String> devicTypes = ["Gasolina", "Gas", "Electrico"];

  Future<void> getImageToSend(int type) async {
    final File? image = (await ImagePicker().pickImage(
        source: type == 0 ? ImageSource.camera : ImageSource.gallery)) as File?;
    selectImage.value = File(image!.path);
  }

  void changedDropDownQuantity(String selected_quantity) {
    current = selected_quantity as RxBool;
    // _producttotal=getProductTotal(_productprice,_currentQuantity);
  }

  void getProfileStorage() {
    //profile.value.add(value)

    Future.delayed(Duration(microseconds: 200), () {});
  }
}
