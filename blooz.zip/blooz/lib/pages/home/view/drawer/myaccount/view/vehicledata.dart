import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/view/drawer/myaccount/mycontroller/MiController.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class VehicleData extends StatelessWidget {
  VehicleData({Key? key}) : super(key: key);
  final _controller = Get.put(MyController());
  var currentSelectedValue;
  List<String> deviceTypes = ["Moto", "Auto", "Van"];

  String dropdownValue = 'One';
  List<String> dropdownValues = ['red', 'green', 'blue'];

  var current;
  List<String> devicTypes = ["Gasolina", "Gas", "Electrico"];

  @override
  Widget build(BuildContext context) {
    var currentValue;
    return Scaffold(
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            children: [
              Expanded(
                  child: ListView(
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            Get.back();
                          },
                          icon: Icon(
                            Icons.arrow_back_ios,
                            size: 20,
                            color: Constant.blue,
                          ),
                        ),
                        Text("Datos del vehiculo"),
                      ],
                    ),
                  ),
                  Container(
                    child: Padding(
                      padding: EdgeInsets.all(15),
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Mi vehiculo',
                              style: TextStyle(color: Constant.blue),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.03),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Tipo de vehiculo',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          InputDecorator(
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                hint: Text(
                                  "Selecciona el tipo de vehiculo",
                                  style: TextStyle(fontSize: 15),
                                ),
                                value: currentSelectedValue,
                                isDense: true,
                                onChanged: (newValue) {
                                  currentSelectedValue = newValue;

                                  if (kDebugMode) {
                                    print(currentSelectedValue);
                                  }
                                },
                                items: deviceTypes.map((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                          /* InputDecorator(
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                hint: Text(
                                  "Selecciona el tipo de vehiculo",
                                  style: TextStyle(fontSize: 15),
                                ),
                                value: dropdownValue,
                                icon: const Icon(Icons.arrow_downward),
                                elevation: 16,
                                style: const TextStyle(color: Colors.deepPurple),
                                underline: Container(
                                  height: 2,
                                  color: Colors.deepPurpleAccent,
                                ),
                                onChanged: (String? newValue) {
                                  dropdownValue = newValue!;
                                },
                                isDense: true,
                                items: <String>[
                                  'One',
                                  'Two',
                                  'Free',
                                  'Four'
                                ].map<DropdownMenuItem<String>>((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),*/

                          /*TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "",
                              suffixIcon: IconButton(
                                onPressed: () {},
                                icon: Icon(
                                  Icons.keyboard_arrow_down_outlined,
                                  size: 35,
                                ),
                              ),
                              hintStyle:
                                  TextStyle(color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),*/
                          SizedBox(height: Get.height * 0.020),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Marca',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "Mini",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          SizedBox(height: Get.height * 0.020),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Modelo',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "clubman",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          SizedBox(height: Get.height * 0.020),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Ano',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "2020",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          SizedBox(height: Get.height * 0.020),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Placa',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              hintText: "AX07V",
                              hintStyle: TextStyle(
                                  color: Colors.black54, fontSize: 13),
                              isDense: true,
                            ),
                            keyboardType: TextInputType.text,
                          ),
                          SizedBox(
                            height: Get.height * 0.020,
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Tipo de combustible',
                              style: TextStyle(color: Colors.black38),
                            ),
                          ),
                          SizedBox(height: Get.height * 0.008),
                          InputDecorator(
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                hint: Text(
                                  "Selecciona el tipo de combustible",
                                  style: TextStyle(fontSize: 15),
                                ),
                                value: current,
                                isDense: true,
                                onChanged: (newValue) {
                                  current.value = newValue! as bool;

                                  if (kDebugMode) {
                                    print(_controller.current);
                                  }
                                },
                                items: devicTypes.map((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: Get.height * 0.020,
                          ),
                          Align(
                            alignment: Alignment.topRight,
                            child: Column(
                              children: [
                                Text('Es propietario'),
                              ],
                            ),
                          ),
                          Row(
                            children: [
                              SizedBox(width: Get.height * 0.33),
                              Obx(
                                () => Checkbox(
                                  value: _controller.owns.value,
                                  onChanged: (newValue) {
                                    _controller.owns.value = newValue!;
                                  },
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: Get.height * 0.02,
                          ),
                          Container(
                            height: 40,
                            width: 160,
                            decoration: Constant.myfulldecoration,
                            //alignment: Alignment.center,
                            // alignment: Alignment.center,
                            child: InkWell(
                              onTap: () {
                                dialogBOxForConferm(context);
                              },
                              child: Center(
                                child: Text(
                                  " Guardar ",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ))
            ],
          ),
        ),
      ),
    );
  }

  void dialogBOxForConferm(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Container(
              child: Column(
                children: [
                  SizedBox(height: Get.height * 0.03),
                  Container(
                    child: CircleAvatar(
                      radius: 30,
                      backgroundColor: Constant.blue,
                      child: const Icon(
                        Icons.check,
                        size: 35,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.040),
                  const Text('!Se han guardado',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  const Text('ios cambios!',
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                      textAlign: TextAlign.center),
                  SizedBox(height: Get.height * 0.040),
                  // const SizedBox(height: 30),
                  const SizedBox(width: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 20),
                    decoration: Constant.myfulldecoration,
                    child: Text(
                      "Aceptar",
                      style: TextStyle(
                        color: Constant.white,
                        fontSize: 12,
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }
}
