import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ConfermDialog extends StatelessWidget {
  // const ConfermDialog ({Key? key}) : super(key: key);
  final HomeController _controller = Get.find();
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Container(
        child: Column(
          children: [
            Container(
              child: CircleAvatar(
                radius: 18,
                backgroundColor: Constant.blue,
                child: Icon(
                  Icons.check,
                  size: 25,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: Get.height * 0.040),
            Text('Se ha elimindo la ruta',
                style: TextStyle(color: Colors.blue, fontSize: 14),
                textAlign: TextAlign.center),
            SizedBox(height: Get.height * 0.040),
            // const SizedBox(height: 30),
            SizedBox(width: 20),
            InkWell(
              onTap: () {
                _controller.getRoutes();
                Get.back();
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                decoration: Constant.myfulldecoration,
                child: Text(
                  "Aceptar",
                  style: TextStyle(
                    color: Constant.white,
                    fontSize: 12,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
