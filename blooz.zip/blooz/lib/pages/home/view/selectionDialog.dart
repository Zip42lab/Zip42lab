import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/home/controller/homeController.dart';
import 'package:blooz/pages/home/view/confermDialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SelectionDialog extends StatelessWidget {
  final HomeController _c = Get.find();
  final String selection;
  final String code;

  SelectionDialog({
    Key? key,
    required this.selection,
    required this.code,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        title: Container(
      child: Column(
        children: [
          const Text('Seguro que desea rechazar \n esta ruta?',
              style: TextStyle(color: Colors.blue, fontSize: 12),
              textAlign: TextAlign.center),
          SizedBox(height: Get.height * 0.040),
          const Text(
            'Esta accion no se puede deshacer',
            style: TextStyle(fontSize: 13),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              const SizedBox(width: 20),
              InkWell(
                onTap: () {
                  // call service
                  Get.back();

                  _c.acceptRejectTask(selection, code);
                  //Get.dialog(ConfermDialog());
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  decoration: Constant.myfulldecoration,
                  child: Text(
                    "Aceptar",
                    style: TextStyle(
                      color: Constant.white,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
              Spacer(),
              InkWell(
                onTap: () {
                  /*  _c.acceptRejectTask(selection, code);
                  Get.dialog(ConfermDialog());*/
                  Get.back();
                },
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  decoration: Constant.myfulldecoration,
                  child: Text(
                    "Cancellar",
                    style: TextStyle(
                      color: Constant.white,
                      fontSize: 12,
                    ),
                  ),
                ),
              )
            ],
          )
        ],
      ),
    ));
  }
}
