// ignore_for_file: file_names, use_key_in_widget_constructors

import 'package:blooz/extras/constants.dart';
import 'package:blooz/pages/login/view/login_page/loginPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

import 'package:get/get.dart';

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            // Top Logo area
            SizedBox(
              height: Get.height * 0.23,
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      //color: Colors.red,
                      child: Image.asset(
                        'assets/images/banner_small.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Image.asset('assets/images/logo_blooz.png'),
                  ),
                ],
              ),
            ),

            /// Bottom Area
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Text(
                      'Register',
                      style: TextStyle(
                          color: Constant.blue, fontWeight: FontWeight.bold),
                    ),
                  ),
                  // ignore: avoid_unnecessary_containers
                  const SizedBox(
                    height: 24,
                  ),
                  const Text(
                    'Nombres',
                    style: TextStyle(color: Colors.black54),
                  ),

                  verticalSpaceViewSmall(),
                  TextField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      hintText: "Argeliandris",
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  verticalSpaceView(),
                  Text(
                    'Apellidos',
                    style: TextStyle(color: Colors.black54),
                  ),
                  verticalSpaceViewSmall(),
                  TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      hintText: "Rincon",
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  verticalSpaceView(),
                  Text(
                    'Correo',
                    style: TextStyle(color: Colors.black54),
                  ),
                  verticalSpaceViewSmall(),
                  TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      hintText: "argierincon@blooz.pe",
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  verticalSpaceView(),
                  Text(
                    'Contrasena',
                    style: TextStyle(color: Colors.black54),
                  ),
                  verticalSpaceViewSmall(),
                  TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      hintText: "Miraflores,Peru",
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  verticalSpaceView(),

                  Text(
                    'Tipo de documento',
                    style: TextStyle(color: Colors.black54),
                  ),
                  verticalSpaceViewSmall(),
                  TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      hintText: "DNI",
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  verticalSpaceView(),

                  Text(
                    'Nro. de documento',
                    style: TextStyle(color: Colors.black54),
                  ),
                  verticalSpaceViewSmall(),
                  TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      hintText: "123456789",
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  verticalSpaceView(),
                  const SizedBox(
                    height: 20,
                  ),
                  Center(
                    child: Container(
                      height: 40,
                      width: Get.width * 0.50,
                      decoration: Constant.myfulldecoration,
                      child: InkWell(
                        onTap: () {
                          Get.to(LoginPage());
                        },
                        child: Center(
                          child: Text(
                            " Ingresar ",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget verticalSpaceView() {
    return const SizedBox(
      height: 16,
    );
  }

  Widget verticalSpaceViewSmall() {
    return const SizedBox(
      height: 6,
    );
  }
}
