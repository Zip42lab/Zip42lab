// ignore_for_file: file_names

import 'package:get/get.dart';

class SignUpController extends GetxController {}
