// ignore_for_file: use_key_in_widget_constructors
import 'package:blooz/pages/home/view/HomePage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'extras/apiProvider.dart';
import 'pages/home/view/homeDetails.dart';
import 'pages/login/view/login_page/loginPage.dart';

Future<void> main() async {
  await GetStorage.init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final _provider = ApiProvider();
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Blooz',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: _provider.checkLogin() ? HomePage() : LoginPage(),
      //  home: LoginPage(),
    );
  }
}
